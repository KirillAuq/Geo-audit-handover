const path = require("path");

// Vercel injects env vars; .env is local-only.
if (!process.env.VERCEL) {
  require("dotenv").config({ path: path.join(__dirname, "..", ".env") });
}

const { createApp } = require("../src/app");

module.exports = createApp();
