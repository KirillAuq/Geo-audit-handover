const path = require("path");
require("../src/load-env").config({ path: path.join(__dirname, "..", ".env") });

const { runAuditAgent } = require("../src/audit-agent");
const fs = require("fs/promises");

async function main() {
  const domain = process.argv[2] || "microblink.com";
  console.log("Running agent audit for", domain);

  const result = await runAuditAgent(domain);
  const outDir = path.join(__dirname, "..", ".data", "runs", result.runId);
  const htmlPath = path.join(outDir, "report.html");

  await fs.writeFile(htmlPath, result.reportHtml, "utf8");
  console.log("Run ID:", result.runId);
  console.log("Brand:", result.brandName);
  console.log("Report HTML:", htmlPath);
  console.log("Memory:", path.join(outDir, "memory.json"));
  console.log("HTML length:", result.reportHtml.length);
  console.log("SUCCESS");
}

main().catch((error) => {
  console.error("FAILED", error.message);
  process.exit(1);
});
