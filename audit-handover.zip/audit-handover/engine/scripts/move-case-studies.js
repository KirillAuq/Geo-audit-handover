#!/usr/bin/env node
// Move the id="auq-case-studies" section higher on the page:
//   - before the "Queries we tested" section (id="tested-queries") when present
//   - otherwise right after the "AI OVERVIEW PERFORMANCE" section (older format)
// Idempotent: files already in the right order are left untouched.
//
// Usage: node scripts/move-case-studies.js [outDir]
// Env:   GEO_AUDIT_OUT_DIR (used when outDir is omitted)
const fs = require("fs");
const path = require("path");

const MARK = '<section class="section" id="auq-case-studies">';

function targetDir() {
  const args = process.argv.slice(2).filter((a) => !a.startsWith("-"));
  if (args.length) return path.resolve(args[0]);
  const env = process.env.GEO_AUDIT_OUT_DIR;
  if (env) return path.resolve(env.replace(/^~/, process.env.HOME || "~"));
  return __dirname;
}

function move(file) {
  const src = fs.readFileSync(file, "utf8");
  const start = src.indexOf(MARK);
  if (start === -1) return "ERROR: no case-studies section";
  let end = src.indexOf("</section>", start);
  if (end === -1) return "ERROR: unterminated case-studies section";
  end += "</section>".length;

  const block = src.slice(start, end);

  // Consume one adjacent newline on each side of the block before removing it,
  // and re-insert with exactly one on each side. Without this, every run adds
  // two bytes and the file creeps, which the original Python version did.
  let s = start;
  let e = end;
  if (src[s - 1] === "\n") s--;
  if (src[e] === "\n") e++;
  const rest = src.slice(0, s) + src.slice(e);

  let anchor = rest.indexOf('<section class="section" id="tested-queries">');
  let how = "before tested-queries";
  if (anchor === -1) {
    const lbl = rest.indexOf("AI OVERVIEW PERFORMANCE");
    if (lbl === -1) return "ERROR: no insertion anchor";
    anchor = rest.indexOf("</section>", lbl);
    if (anchor === -1) return "ERROR: no </section> after AI OVERVIEW PERFORMANCE";
    anchor += "</section>".length;
    how = "after AI Overview Performance";
  }

  const out = rest.slice(0, anchor) + "\n" + block + "\n" + rest.slice(anchor);
  if (out !== src) {
    fs.writeFileSync(file, out);
    return `moved (${how})`;
  }
  return "unchanged";
}

function main() {
  const dir = targetDir();
  const files = fs.readdirSync(dir).filter((f) => f.endsWith(".html") && f !== "index.html").sort();
  const counts = {};
  const errors = {};
  for (const f of files) {
    const r = move(path.join(dir, f));
    const key = r.split(" (")[0];
    counts[key] = (counts[key] || 0) + 1;
    if (r.startsWith("ERROR")) errors[f] = r;
  }
  console.log(counts);
  for (const [k, v] of Object.entries(errors)) console.log(`  ${k}: ${v}`);
  return Object.keys(errors).length ? 1 : 0;
}

if (require.main === module) process.exit(main());
