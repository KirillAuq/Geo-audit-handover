#!/usr/bin/env node
// Print the insight fact sheet per audited domain: the grounding for the
// "What it found" and "Pitch" chat write-up that closes every audit.
//
// Usage: node scripts/insights.js [--json] domain1.com domain2.com[:slug] ...
//
// Reads the latest complete run per domain from .data/runs/*/. Uses
// canonical.json's analysis.insightFacts when present, and computes it from
// memory.json + canonical.json for runs made before that key existed. No
// network, no LLM. Run verify first; this does not judge whether a run is
// clean. Exit code is non-zero if any domain has no complete run.
const fs = require("fs");
const path = require("path");
const { buildFacts, formatFacts } = require("../src/insights");

const RUNS = path.join(__dirname, "..", ".data", "runs");
const domainOf = (a) => a.split(":")[0].toLowerCase();
const readJson = (p) => { try { return JSON.parse(fs.readFileSync(p, "utf8")); } catch { return null; } };

function latestRuns(wanted) {
  let dirs = [];
  try { dirs = fs.readdirSync(RUNS); } catch { return {}; }
  const best = {};
  for (const dir of dirs) {
    const mp = path.join(RUNS, dir, "memory.json");
    let st;
    try { st = fs.statSync(mp); } catch { continue; }
    const m = readJson(mp);
    const d = String(m?.meta?.domain || "").toLowerCase();
    if (!wanted.has(d) || !Array.isArray(m.aio?.results) || m.aio.partial) continue;
    if (!best[d] || st.mtimeMs > best[d].mtime) best[d] = { runId: dir, mtime: st.mtimeMs, memory: m };
  }
  return best;
}

function main() {
  const argv = process.argv.slice(2).filter((a) => a.trim());
  const json = argv.includes("--json");
  const args = argv.filter((a) => a !== "--json");
  if (!args.length) { console.log("usage: node scripts/insights.js [--json] domain1.com domain2.com ..."); return 2; }
  const runs = latestRuns(new Set(args.map(domainOf)));
  const all = [];
  let missing = 0;
  for (const a of args) {
    const d = domainOf(a);
    const run = runs[d];
    if (!run) { missing++; if (!json) console.log(`=== ${d}: no complete run found\n`); continue; }
    const canon = readJson(path.join(RUNS, run.runId, "canonical.json"));
    const facts = canon?.analysis?.insightFacts || buildFacts(run.memory, canon);
    if (json) all.push({ runId: run.runId, ...facts });
    else console.log(formatFacts(facts, run.runId) + "\n");
  }
  if (json) console.log(JSON.stringify(all, null, 2));
  return missing ? 1 : 0;
}

if (require.main === module) process.exit(main());
