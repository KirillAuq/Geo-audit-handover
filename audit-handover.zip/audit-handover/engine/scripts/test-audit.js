const path = require("path");
require("../src/load-env").config({ path: path.join(__dirname, "..", ".env") });

const { runAuditAgent } = require("../src/audit-agent");

async function main() {
  const domain = process.argv[2] || "microblink.com";
  console.log("Running agent audit for", domain);

  const result = await runAuditAgent(domain);
  console.log("Run ID:", result.runId);
  console.log("Brand:", result.brandName);
  console.log("Report HTML chars:", result.reportHtml.length);
  console.log("Memory keys:", result.memory.keys().join(", "));
  console.log("SUCCESS");
}

main().catch((error) => {
  console.error("FAILED", error.message);
  process.exit(1);
});
