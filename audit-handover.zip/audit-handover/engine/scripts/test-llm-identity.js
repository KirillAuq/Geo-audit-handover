#!/usr/bin/env node
// Offline tests for the LLM identity check. No network and no billable calls.
const assert = require("assert");
const fs = require("fs");
const os = require("os");
const path = require("path");
const { spawnSync } = require("child_process");

const {
  identityPrompt,
  identityRequestBody,
  collectIdentity,
  snapshotFromLive,
} = require("../src/llm-identity");
const { phraseCheck } = require("../src/llm-identity-compare");
const { build } = require("./normalize_aio");
const { render, loadRenderInput } = require("./render-roboflow");

let failed = 0;
function check(name, fn) {
  try {
    fn();
    console.log("ok  ", name);
  } catch (err) {
    failed++;
    console.error("FAIL", name);
    console.error(err && err.stack || err);
  }
}

check("prompt is neutral and rejects an empty brand", () => {
  assert.strictEqual(identityPrompt("Acme"), "What does Acme do?");
  assert.throws(() => identityPrompt("  "), /brand is required/);
});

check("gemini body omits web_search_country_iso_code and the baseline", () => {
  const baseline = "Acme makes widgets for hospitals and nothing else.";
  const body = identityRequestBody("gemini", {
    prompt: identityPrompt("Acme"),
    modelName: "gemini-2.5-flash",
    webSearchCountryIsoCode: "US",
    baseline,
  });
  assert.strictEqual(body.user_prompt, "What does Acme do?");
  assert.strictEqual(body.model_name, "gemini-2.5-flash");
  assert.strictEqual(body.web_search, true);
  assert.ok(!Object.prototype.hasOwnProperty.call(body, "web_search_country_iso_code"));
  assert.ok(!JSON.stringify(body).includes(baseline));
  assert.ok(!JSON.stringify(body).includes("hospitals"));
});

check("chatgpt body also omits the country field", () => {
  const body = identityRequestBody("chatgpt", {
    prompt: "What does Acme do?",
    modelName: "gpt-5",
    webSearchCountryIsoCode: "US",
  });
  assert.ok(!("web_search_country_iso_code" in body));
});

check("a failed live payload is not tested and has no invented text", () => {
  const snap = snapshotFromLive(1, "gemini-2.5-flash", {
    httpStatus: 200,
    json: { status_code: 40501, status_message: "Invalid Field: 'web_search_country_iso_code'." },
  });
  assert.strictEqual(snap.ok, false);
  assert.strictEqual(snap.text, null);
  assert.strictEqual(snap.failure.statusCode, 40501);
});

check("phrase check does not invent semantic alignment or a percentage", () => {
  const dims = phraseCheck({
    categoryLabels: ["organizational intelligence"],
    buyerPhrases: ["HR and Finance"],
    capabilityPhrases: ["headcount planning"],
    positioningPhrases: [],
  }, "Acme is an organizational intelligence company that helps HR and Finance teams.");
  const by = Object.fromEntries(dims.map((d) => [d.dimension, d]));
  assert.strictEqual(by.category.verdict, "exact_or_near_slogan");
  assert.strictEqual(by.buyers.verdict, "unknown");
  assert.strictEqual(by.capabilities.verdict, "omission");
  assert.strictEqual(by.positioning.verdict, "unknown");
  assert.strictEqual(by.factual.verdict, "unknown");
  assert.ok(!JSON.stringify(dims).includes("semantic_alignment"));
  assert.ok(!JSON.stringify(dims).includes("%"));
});

check("score weights and formula stay on a fixed memory", () => {
  const memory = {
    meta: { domain: "acme.com", brand: "Acme" },
    identity: { brand: "Acme", categories: ["widgets"] },
    aio: {
      queryCount: 2,
      counts: { owned: 1, mentioned_not_cited: 0, invisible: 1, no_aio: 0 },
      topPeers: [],
      results: [
        { query: "best widgets", layer: "positioning", bucket: "owned", citedDomains: ["acme.com"] },
        { query: "widgets software", layer: "positioning", bucket: "invisible", citedDomains: ["other.example"] },
      ],
    },
  };
  const canon = build(memory);
  assert.deepStrictEqual(
    canon.geoScore.components.map((c) => [c.label, c.weightPct, c.scoreOutOf100]),
    [
      ["Your pages being quoted", 35, 50],
      ["Inclusion in category answers", 25, 50],
      ["How AI describes the brand", 20, 100],
      ["Topic coverage breadth", 20, 100],
    ],
  );
  // round(0.35*50 + 0.25*50 + 0.20*100 + 0.20*100) = round(17.5+12.5+20+20) = 70
  assert.strictEqual(canon.geoScore.overallScore, 70);
  assert.strictEqual(canon.geoScore.band, "Competitive");
});

check("a historical canonical renders Not tested and keeps its score", () => {
  const runs = path.join(__dirname, "..", ".data", "runs");
  const canonPath = fs.readdirSync(runs)
    .map((id) => path.join(runs, id, "canonical.json"))
    .find((p) => fs.existsSync(p));
  const canon = JSON.parse(fs.readFileSync(canonPath, "utf8"));
  const html = render(canon);
  assert.ok(html.includes(`>${canon.geoScore.overallScore}<`) || html.includes(`>${canon.geoScore.overallScore}</div>`));
  assert.ok(html.includes("What do LLMs say"));
  assert.ok(html.includes("Not tested. The LLM identity check was not run for this report."));
  assert.ok(!html.includes("What Google's AI says"));
  assert.ok(html.includes("theme presence in the Google AI Overview query set"));
  assert.strictEqual(canon.geoScore.components[2].weightPct, 20);
});

check("sanitized fixture renders excerpts, metadata, and no vendor name", () => {
  const fixture = JSON.parse(fs.readFileSync(path.join(__dirname, "..", "fixtures/llm-identity/sanitized-charthop.json"), "utf8"));
  const html = render({
    meta: { domain: "charthop.com", completedAt: "2026-11-06T17:07:09.649Z" },
    geoScore: {
      brand: "ChartHop",
      overallScore: 34,
      band: "Low",
      components: [
        { label: "Your pages being quoted", weightPct: 35, scoreOutOf100: 8 },
        { label: "Inclusion in category answers", weightPct: 25, scoreOutOf100: 45 },
        { label: "How AI describes the brand", weightPct: 20, scoreOutOf100: 83 },
        { label: "Topic coverage breadth", weightPct: 20, scoreOutOf100: 17 },
      ],
    },
    analysis: { aioPerformance: { trackedKeywords: 38, aioTriggerCount: 38, aioTriggerRatePct: "100%", brandCitedInAioCount: 3, brandCitationRatePct: "8%" } },
    llmIdentity: fixture,
  });
  assert.ok(html.includes(">34<"));
  assert.ok(html.includes("What does ChartHop do?"));
  assert.ok(html.includes("gpt-5.4-mini-2026-03-17"));
  assert.ok(html.includes("gemini-2.5-flash"));
  assert.ok(html.includes("claude-sonnet-4-5-20250929"));
  assert.ok(html.includes("sonar-pro"));
  assert.ok(html.includes("organizational intelligence"));
  assert.ok(html.includes("not a screenshot of the consumer chat app"));
  assert.ok(html.includes("Reviewer note"));
  assert.ok(!/dataforseo/i.test(html));
  assert.ok(!html.includes("\u2014") && !html.includes("\u2013"));
});

check("a missing provider in an otherwise real run renders Not tested", () => {
  const html = render({
    meta: { domain: "acme.com" },
    geoScore: { brand: "Acme", overallScore: 10, band: "Absent", components: [] },
    llmIdentity: {
      status: "partial",
      prompt: "What does Acme do?",
      providers: [
        { id: "chatgpt", label: "ChatGPT", status: "ok", snapshots: [{ ok: true, sample: 1, model: "returned-model", datetimeUtc: "2026-11-06 00:00:00 +00:00", webSearch: true, text: "Acme builds widgets for hospitals.", citations: [] }] },
      ],
    },
  });
  assert.ok(html.includes("Acme builds widgets for hospitals."));
  assert.ok(html.includes("Partial. 1 snapshot. The target is 2."));
  assert.ok(html.includes("Gemini"));
  assert.ok((html.match(/Not tested\./g) || []).length >= 3);
  assert.ok(!html.includes("google.com"));
});

check("a run directory merges llm-identity.json without replacing the stored score", () => {
  const dir = fs.mkdtempSync(path.join(os.tmpdir(), "llm-id-"));
  fs.writeFileSync(path.join(dir, "canonical.json"), JSON.stringify({
    meta: { domain: "acme.com" },
    geoScore: { brand: "Acme", overallScore: 41, band: "Low", components: [] },
  }));
  fs.writeFileSync(path.join(dir, "memory.json"), JSON.stringify({ meta: { domain: "acme.com" }, geoScore: { overallScore: 1 } }));
  fs.writeFileSync(path.join(dir, "llm-identity.json"), JSON.stringify({
    prompt: "What does Acme do?",
    providers: [],
  }));
  const loaded = loadRenderInput(dir);
  assert.strictEqual(loaded.geoScore.overallScore, 41);
  assert.strictEqual(loaded.llmIdentity.prompt, "What does Acme do?");
  const html = render(loaded);
  assert.ok(html.includes(">41<"));
  assert.ok(html.includes("Not tested"));
});

check("collect-identity without credentials writes Not tested and does not call the network", () => {
  const out = path.join(os.tmpdir(), "acme.llm-identity.json");
  const env = { ...process.env, GEO_AUDIT_ENGINE_DIR: path.join(__dirname, "..") };
  delete env.GEO_AUDIT_DATAFORSEO_LOGIN;
  delete env.GEO_AUDIT_DATAFORSEO_PASSWORD;
  delete env.DATAFORSEO_LOGIN;
  delete env.DATAFORSEO_PASSWORD;
  const res = spawnSync(process.execPath, [path.join(__dirname, "collect-identity.js"), "acme.com", "Acme", "--out", out], { env, encoding: "utf8" });
  assert.strictEqual(res.status, 2, res.stderr);
  const written = JSON.parse(fs.readFileSync(out, "utf8"));
  assert.strictEqual(written.status, "not_tested");
  assert.ok(written.providers.every((p) => p.status === "not_tested"));
  assert.ok(!/password|authorization/i.test(JSON.stringify(written)));
  assert.ok(!res.stdout.includes("Basic "));
  assert.ok(!res.stderr.includes("Basic "));
});

async function main() {
  // The collector check is async and was registered via check() which does not await.
  // Re-run it here so a rejection fails the process.
  const posted = [];
  const post = async (pathname, req) => {
    posted.push(req.body || null);
    if (pathname.endsWith("/models")) {
      if (pathname.includes("claude")) {
        return { httpStatus: 200, json: { status_code: 20000, tasks: [{ result: [] }] } };
      }
      return { httpStatus: 200, json: { tasks: [{ result: [{ model_name: "model-from-list" }] }] } };
    }
    return {
      httpStatus: 200,
      json: {
        status_code: 20000,
        cost: 0.02,
        tasks: [{
          status_code: 20000,
          cost: 0.02,
          result: [{
            model_name: "model-returned",
            datetime: "2026-11-06 12:00:00 +00:00",
            web_search: true,
            items: [{ sections: [{ text: "Acme builds widgets." }] }],
          }],
        }],
      },
    };
  };
  const record = await collectIdentity({ brand: "Acme", samples: 2, post, baseline: { categoryLabels: ["widgets"] } });
  assert.strictEqual(record.providers.find((p) => p.id === "chatgpt").snapshots[1].model, "model-returned");
  assert.strictEqual(record.providers.find((p) => p.id === "claude").status, "not_tested");
  assert.ok(posted.filter(Boolean).every((body) => body.user_prompt === "What does Acme do?" && !("web_search_country_iso_code" in body)));
  console.log("ok   async collector");

  const fixtureHtml = path.join(os.tmpdir(), "charthop-identity-render-check");
  fs.mkdirSync(fixtureHtml, { recursive: true });
  const fixture = JSON.parse(fs.readFileSync(path.join(__dirname, "..", "fixtures/llm-identity/sanitized-charthop.json"), "utf8"));
  const html = render({
    meta: { domain: "charthop.com", completedAt: "2026-11-06T17:07:09.649Z" },
    geoScore: { brand: "ChartHop", overallScore: 34, band: "Low", bandDescription: "Cited on 3 of 38.", components: [] },
    analysis: { aioPerformance: {} },
    llmIdentity: fixture,
  });
  const file = path.join(fixtureHtml, "charthop.html");
  fs.writeFileSync(file, html);
  const checked = spawnSync(process.execPath, [path.join(__dirname, "check-reports.js"), fixtureHtml], {
    env: { ...process.env },
    encoding: "utf8",
  });
  if (checked.status !== 0) {
    console.error(checked.stdout);
    console.error(checked.stderr);
    throw new Error("check-reports failed on the fixture render");
  }
  console.log("ok   check-reports on fixture render");
  if (failed) {
    console.error(failed + " failed");
    process.exit(1);
  }
  console.log("all identity tests passed");
}

main().catch((err) => {
  console.error(err);
  process.exit(1);
});
