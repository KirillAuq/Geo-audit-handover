const path = require("path");
require("../src/load-env").config({ path: path.join(__dirname, "..", ".env") });

const { collectAhrefsData, brandRadarMentionTotal } = require("../src/ahrefs-mcp");

async function main() {
  const domain = process.argv[2] || "microblink.com";
  const { results, errors, warnings } = await collectAhrefsData(domain);

  console.log("domain:", results.domain);
  console.log("brand:", results.brandName);
  console.log("data source:", results.brandRadarDataSource);
  console.log("mentions total:", brandRadarMentionTotal(results.mentionsOverview));
  console.log("cited pages:", results.citedPages?.pages?.length ?? 0);
  console.log("cited domains:", results.citedDomains?.domains?.length ?? 0);
  console.log("organic keywords:", results.organicKeywords?.keywords?.length ?? 0);
  console.log("errors:", errors.length ? errors : "none");
  console.log("warnings:", warnings.length ? warnings : "none");

  if (errors.length) process.exit(1);
}

main().catch((error) => {
  console.error(error.message);
  process.exit(1);
});
