const path = require("path");
const fs = require("fs/promises");

require("../src/load-env").config({ path: path.join(__dirname, "..", ".env") });

const { AgentMemory } = require("../src/agent-memory");
const { runChunkedReport } = require("../src/report-chunks");

async function main() {
  const runId = process.argv[2];
  if (!runId) {
    console.error("Usage: node scripts/generate-report.js <runId>");
    process.exit(1);
  }

  const memory = await AgentMemory.load(runId);
  console.log("Regenerating chunked report for run", runId);

  const result = await runChunkedReport({
    memory,
    directions: "",
    onProgress: (id) => console.log("  chunk:", id),
  });

  const outPath = path.join(__dirname, "..", ".data", "runs", runId, "report.html");
  await fs.writeFile(outPath, result.html, "utf8");
  memory.set("reportHtml", result.html);
  await memory.save();

  console.log("Chunks ok:", result.log.chunks.length);
  console.log("Chunks failed:", result.log.failed.length);
  if (result.log.failed.length) console.log(result.log.failed);
  console.log("HTML length:", result.html.length);
  console.log("Written:", outPath);
  console.log(result.partial ? "PARTIAL" : "SUCCESS");
}

main().catch((error) => {
  console.error("FAILED", error.message);
  process.exit(1);
});
