#!/usr/bin/env node
// Separate from the Google AI Overview score.
// Asks "What does {brand} do?" on ChatGPT, Gemini, Claude, and Perplexity.
// Writes llm-identity.json. Does not put the brand baseline in the prompt.
//
// Usage:
//   node scripts/collect-identity.js <domain> <brand> [--samples 2] [--baseline file.json] [--out file.json]
//
// Credentials: GEO_AUDIT_DATAFORSEO_LOGIN / GEO_AUDIT_DATAFORSEO_PASSWORD.
// DATAFORSEO_LOGIN / DATAFORSEO_PASSWORD are accepted aliases. Values are never printed.
const fs = require("fs");
const path = require("path");
require("../src/load-env").config({ path: path.join(__dirname, "..", ".env") });

const { collectIdentity, defaultPost, assertNoSecretKeys, publicError } = require("../src/llm-identity");
const { compareSnapshot } = require("../src/llm-identity-compare");

function arg(name, fallback) {
  const i = process.argv.indexOf(name);
  if (i === -1) return fallback;
  return process.argv[i + 1];
}

function notTestedFile(brand, message) {
  return {
    status: "not_tested",
    prompt: brand ? `What does ${brand} do?` : null,
    promptRule: "Exact neutral prompt. No system message. No brand baseline in the request.",
    transport: "LLM Responses API, Live method. Not a consumer chat screenshot.",
    providersTarget: 3,
    samplesTarget: 2,
    baseline: null,
    providers: [
      ["chatgpt", "ChatGPT"],
      ["gemini", "Gemini"],
      ["claude", "Claude"],
      ["perplexity", "Perplexity"],
    ].map(([id, label]) => ({
      id,
      label,
      status: "not_tested",
      failure: { message },
      snapshots: [],
    })),
  };
}

function attachComparison(record, baseline) {
  if (!baseline) return record;
  for (const provider of record.providers || []) {
    const sample = (provider.snapshots || []).find((s) => s.ok && s.text);
    provider.comparison = sample
      ? compareSnapshot(baseline, sample.text, provider.reviewerDimensions)
      : null;
  }
  return record;
}

async function main() {
  const domain = process.argv[2];
  const brand = process.argv[3];
  if (!domain || !brand || domain.startsWith("--")) {
    console.error("Usage: node scripts/collect-identity.js <domain> <brand> [--samples 2] [--baseline file.json] [--out file.json]");
    process.exit(1);
  }
  const samples = Number(arg("--samples", "2")) || 2;
  const baselinePath = arg("--baseline", "");
  const out = arg("--out", "");
  let baseline = null;
  if (baselinePath) {
    baseline = JSON.parse(fs.readFileSync(baselinePath, "utf8"));
    assertNoSecretKeys(baseline);
  }
  const outPath = out || path.join(process.cwd(), `${domain.replace(/[^a-z0-9.]+/gi, "-")}.llm-identity.json`);
  let record;
  try {
    record = await collectIdentity({
      brand,
      samples,
      baseline,
      post: defaultPost,
      tagPrefix: domain.split(".")[0],
    });
  } catch (err) {
    if (err.code === "NO_CREDENTIALS") {
      record = notTestedFile(brand, "Not tested. Credentials were not set.");
      fs.writeFileSync(outPath, JSON.stringify(record, null, 2) + "\n");
      console.error("Not tested. Set GEO_AUDIT_DATAFORSEO_LOGIN and GEO_AUDIT_DATAFORSEO_PASSWORD. Wrote", outPath);
      process.exit(2);
    }
    record = notTestedFile(brand, publicError(err));
  }
  attachComparison(record, baseline);
  record.domain = domain;
  record.brand = brand;
  assertNoSecretKeys(record);
  fs.writeFileSync(outPath, JSON.stringify(record, null, 2) + "\n");
  const ok = (record.providers || []).filter((p) => p.status === "ok" || p.status === "partial").length;
  console.log(`Wrote ${outPath} | ${record.status} | providers with a snapshot ${ok}`);
  if (record.status === "not_tested") process.exit(2);
}

if (require.main === module) {
  main().catch((err) => {
    console.error(publicError(err));
    process.exit(1);
  });
}

module.exports = { attachComparison, notTestedFile };
