#!/usr/bin/env node
// Render a completed GEO audit run (memory.json) into the AUQ "roboflow" house design.
// Usage: node scripts/render-roboflow.js <runDir|memory.json> <out.html>
// Design source: templates/roboflow.css (+ roboflow.fonts.html), structure mirrors
// kirillauq.github.io/kirillauq/roboflow-geo-audit.html

const fs = require("fs");
const path = require("path");
const { publicSummary } = require("../src/llm-identity-match");

const TPL = path.join(__dirname, "..", "templates");
const CSS = fs.readFileSync(path.join(TPL, "roboflow.css"), "utf8");
const FONTS = fs.readFileSync(path.join(TPL, "roboflow.fonts.html"), "utf8");

// Google Tag Manager — injected into every rendered audit so published pages are
// tracked consistently (GTM container shared with the auq-geo-audits index).
// Analytics. Every report carries the AUQ GTM container by default, shared with
// the audits index so reports are tracked consistently. Override with
// GEO_AUDIT_GTM_ID to use a different container, or set it to "off" to render a
// report with no tag at all (useful when a client's agreement forbids one).
// Note these are local files: the tag fires from the recipient's machine
// whenever they open the report.
const GTM_ID = (process.env.GEO_AUDIT_GTM_ID ?? "GTM-NCFX8NJ").trim();
const GTM_ON = GTM_ID && GTM_ID.toLowerCase() !== "off";
const GTM_HEAD = GTM_ON ? `<!-- Google Tag Manager --><script>(function(w,d,s,l,i){w[l]=w[l]||[];w[l].push({'gtm.start':new Date().getTime(),event:'gtm.js'});var f=d.getElementsByTagName(s)[0],j=d.createElement(s),dl=l!='dataLayer'?'&l='+l:'';j.async=true;j.src='https://www.googletagmanager.com/gtm.js?id='+i+dl;f.parentNode.insertBefore(j,f);})(window,document,'script','dataLayer','${GTM_ID}');</script><!-- End Google Tag Manager -->` : "";
const GTM_BODY = GTM_ON ? `<!-- Google Tag Manager (noscript) --><noscript><iframe src="https://www.googletagmanager.com/ns.html?id=${GTM_ID}" height="0" width="0" style="display:none;visibility:hidden"></iframe></noscript><!-- End Google Tag Manager (noscript) -->` : "";

// ---- helpers ----------------------------------------------------------------
const esc = (s) =>
  String(s == null ? "" : s)
    .replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;");
// strip em/en dashes per spec (no em dashes, "to" for ranges handled upstream)
const clean = (s) => esc(s).replace(/—/g, ", ").replace(/–/g, " to ");
const pct = (x) => (x == null ? "" : typeof x === "string" ? x : Math.round(x * 100) + "%");
const arr = (x) => (Array.isArray(x) ? x : []);
const dot = ' &nbsp;·&nbsp; ';

function fmtDate(iso) {
  try {
    const d = new Date(iso);
    return d.toLocaleDateString("en-US", { year: "numeric", month: "long", day: "numeric" });
  } catch { return iso; }
}

// ---- section builders -------------------------------------------------------
function hero(m, brand) {
  const a = m.analysis || {}, p = a.aioPerformance || {}, g = m.geoScore || {};
  const meta = m.meta || {};
  const cards = [
    { lbl: "AI Visibility Score", cls: "accent", num: g.overallScore ?? meta.geoScore ?? "", sub: `out of 100. ${clean(g.band || meta.geoBand || "")} band. ${clean(g.bandDescription || "")}` },
    { lbl: "Verified AI Overview citations", cls: "good", num: p.brandCitedInAioCount ?? "", sub: `Elisity's brand is cited in ${p.brandCitedInAioCount ?? "?"} of the ${p.aioTriggerCount ?? "?"} AI-answer queries we tested.`.replace(/Elisity/g, clean(brand)) },
    { lbl: "AI answer trigger rate", cls: "", num: p.aioTriggerRatePct || pct(p.aioTriggerRate), sub: `Google's AI answer box fires on ${p.aioTriggerCount ?? "?"} of ${p.trackedKeywords ?? "?"} tracked queries.` },
    { lbl: "Citation rate when AI answers", cls: "", num: p.brandCitationRatePct || pct(p.brandCitationRate), sub: `Share of AI-answer queries where the brand is actually quoted.` },
  ];
  return `
<section class="hero"><div class="container">
  <div class="eyebrow"><span class="pill"></span><span class="mono-label">GEO AUDIT${dot}BRAND-ONLY</span></div>
  <h1 class="display">${clean(brand)}.</h1>
  <p class="lede">A look at how ${clean(brand)} is described, positioned, and quoted inside Google's AI Overviews, the AI answer box at the top of search results, and where the brand shows up versus goes missing.</p>
  <div class="meta">
    <div class="row"><span class="k">Site</span><span class="v">${clean(m.meta.domain)}</span></div>
    <div class="row"><span class="k">Where we looked</span><span class="v">Google AI Overviews, US</span></div>
    <div class="row"><span class="k">Questions tested</span><span class="v">${p.trackedKeywords ?? "40"} brand, category, and competitor queries</span></div>
    <div class="row"><span class="k">Prepared</span><span class="v">${fmtDate(meta.completedAt || a.analyzedAt)}${dot}by AUQ</span></div>
  </div>
  <div class="stats-bar">
    ${cards.map((c) => `<div class="stat-card"><div class="lbl">${clean(c.lbl)}</div><div class="num ${c.cls}">${clean(c.num)}</div><div class="sub">${clean(c.sub)}</div></div>`).join("")}
  </div>
</div></section>`;
}

const COMP_LABELS = {
  aioTriggerRate: "How often AI answers appear",
  brandCitationRate: "Inclusion in category answers",
  citationPosition: "Quality of placement when cited",
  identityClarity: "How AI describes the brand",
  contentCoverageDepth: "Topic coverage breadth",
  ownPageCitationQuality: "Your pages being quoted",
};

function execSummary(m, brand) {
  const g = m.geoScore || {}, a = m.analysis || {};
  const score = g.overallScore ?? 0;
  const onSegs = score < 25 ? 1 : score < 50 ? 2 : score < 75 ? 3 : 4;
  const segs = [0, 1, 2, 3].map((i) => `<div class="seg${i < onSegs ? " on" : ""}"></div>`).join("");
  const compEntries = Array.isArray(g.components)
    ? g.components.map((c) => [c.label, c.scoreOutOf100 != null ? c.scoreOutOf100 : (c.maxWeightedScore ? Math.round((c.weightedScore / c.maxWeightedScore) * 100) : c.rawScore), c.weightPct])
    : Object.entries(g.components || {}).map(([k, c]) => [COMP_LABELS[k] || c.label, c.maxWeightedScore ? Math.round((c.weightedScore / c.maxWeightedScore) * 100) : c.rawScore, c.weightPct]);
  const comps = compEntries.map(([label, out, w]) =>
    `<li><span class="lbl">${clean(label)}${w ? ` <span class="wt">${w}%</span>` : ""}</span><span class="val">${out == null ? "" : out} / 100</span></li>`).join("");

  const p = a.aioPerformance || {};

  return `
<section class="section"><div class="container">
  <div class="section-head"><span class="mono-label">EXECUTIVE SUMMARY</span>
    <h2>${clean(brand)} scores ${score} of 100 for AI Overview visibility. The work is closing the citation and identity gaps.</h2></div>
  <div class="grid grid-2" style="gap:32px;">
    <div class="stack-md">
      <p class="lede">${clean(g.bandDescription || "")}</p>
      <p>${clean(`AI answers fire on ${p.aioTriggerRatePct} of tracked queries, yet ${brand} is quoted in only ${p.brandCitationRatePct} of them. When it does appear, it sits ${p.brandPositionWhenCited || "mid-list"}.`)}</p>
    </div>
    <div class="score-block"><div class="num-side">
      <div class="mono-label">AI Visibility Score</div><div class="big">${score}</div>
      <div class="band"><span>${clean(g.band)} band</span></div>
      <div class="scale">${segs}</div>
      <div class="scale-lbl"><span>Barely</span><span>Low</span><span>Competitive</span><span>Dominant</span></div>
    </div>
    <div class="components"><div class="mono-label" style="margin-bottom:14px;">What's in the score</div><ul>${comps}</ul>
      <p>The 20% line is theme presence in Google AI Overviews. The description-match percent in the identity section is separate and does not change this score.</p>
    </div></div>
  </div>
</div></section>`;
}

// Findings + top moves. Rendered AFTER Content/Entity Coverage and AI Overview
// Performance (per layout spec) so the reader sees the supporting data first.
function keyFindings(m, brand) {
  const g = m.geoScore || {}, a = m.analysis || {};
  const p = a.aioPerformance || {}, ig = a.identityGap || {};
  const missShare = p.brandCitationRate != null ? Math.round((1 - p.brandCitationRate) * 100) + "%" : "most";
  const findings = [
    { h: `The brand is missing from ${missShare} of AI-answer queries`, p: p.aioAppearanceNotes || `Cited in only ${p.brandCitationRatePct} of the queries where Google's AI answers.` },
    { h: `AI misreads the category`, p: ig.aioCategoryMisalignment || (arr(ig.aioGaps)[0] || "") },
    { h: `Owned pages are barely quoted`, p: (g.components?.ownPageCitationQuality?.notes) || "" },
  ].filter((f) => f.p);

  const moves = arr(g.topLeverageMoves).slice(0, 3).map((mv, i) =>
    `<div class="finding"><div class="num">0${i + 1}</div><h3>${clean(mv.move)}</h3><p>${clean([mv.impact && `Impact ${mv.impact}`, mv.effort && `effort ${mv.effort}`, mv.timeframe].filter(Boolean).join(dot.replace(/&nbsp;/g, " ")))}</p></div>`
  ).join("");

  return `
<section class="section"><div class="container">
  <div class="section-head"><span class="mono-label">THREE FINDINGS THAT MATTER</span></div>
  <div class="findings">${findings.map((f, i) => `<div class="finding"><div class="num">0${i + 1}</div><h3>${clean(f.h)}</h3><p>${clean(f.p)}</p></div>`).join("")}</div>
  <div class="section-head" style="margin-top:40px;"><span class="mono-label">TOP THREE MOVES</span></div>
  <div class="findings">${moves}</div>
</div></section>`;
}

function llmRecord(m) {
  return m.llmIdentity || m.analysis?.llmIdentity || null;
}

function gapSentence(gaps) {
  if (!gaps.length) return "The reviewed homepage claims showed up across the answers.";
  if (gaps.length === 1) return `${gaps[0]} was often left out.`;
  const last = gaps[gaps.length - 1];
  const head = gaps.slice(0, -1).join(", ");
  return `${head} and ${last} were often left out.`;
}

function identity(m, brand) {
  const rec = llmRecord(m);
  const title = `What do LLMs say ${clean(brand)} is?`;
  if (!rec) {
    return `
<section class="section" id="llm-identity"><div class="container">
  <div class="section-head"><span class="mono-label">DESCRIPTION MATCH</span><h2>${title}</h2></div>
  <p>Not scored. No reviewed homepage claim list was attached, so no description-match percent is shown.</p>
</div></section>`;
  }
  const summary = publicSummary(rec);
  const says = summary.says
    ? `<h3>What ${clean(brand)} says it is</h3><p>${clean(summary.says)}</p>`
    : "";
  if (summary.match.percent == null) {
    return `
<section class="section" id="llm-identity"><div class="container">
  <div class="section-head"><span class="mono-label">DESCRIPTION MATCH</span><h2>${title}</h2></div>
  ${says}
  <p>Not scored. The answers were not reviewed against the homepage claims, so no description-match percent is shown.</p>
</div></section>`;
  }
  const wrong = summary.contradictions.length
    ? `Factual error. ${summary.contradictions[0]}`
    : "No clear factual errors.";
  const showedUp = summary.gaps.length || summary.contradictions.length
    ? ""
    : "The reviewed homepage claims showed up across the answers.";
  const leftOut = summary.failed === 1
    ? " 1 model returned no answer and is left out."
    : summary.failed > 1
      ? ` ${summary.failed} models returned no answer and are left out.`
      : "";
  return `
<section class="section" id="llm-identity"><div class="container">
  <div class="section-head"><span class="mono-label">DESCRIPTION MATCH</span><h2>${title}</h2></div>
  ${says}
  <p class="display" style="font-size:72px;line-height:1;margin:12px 0;">${summary.match.percent}%</p>
  <p>Share of homepage claims reflected across ${summary.match.answers} answers from ${summary.match.models} models.${leftOut}</p>
  <h3>What the models got wrong / missed</h3>
  <p>${clean(wrong)}${summary.gaps.length ? " " + clean(gapSentence(summary.gaps)) : showedUp ? " " + clean(showedUp) : ""} This does not check every sentence the models wrote.</p>
</div></section>`;
}

function performance(m, brand) {
  const p = m.analysis?.aioPerformance || {};
  const stats = [
    { lbl: "Tracked keywords", num: p.trackedKeywords, sub: "Brand, category, and comparison queries analyzed." },
    { lbl: "AI answers fired", num: p.aioTriggerCount, sub: `${p.aioTriggerRatePct} of tracked queries trigger an AI Overview.` },
    { lbl: "Times brand cited", num: p.brandCitedInAioCount, sub: `${p.brandCitationRatePct} citation rate when AI answers.` },
    { lbl: "Total brand mentions", num: p.mentionsTotal, sub: "Across all observed AI responses." },
  ];
  const missed = arr(p.highValueMissedKeywords).slice(0, 10).map((k) =>
    `<tr><td>${clean(k.keyword)}</td><td>${clean(k.volume)}</td><td>#${clean(k.position)}</td><td>${clean(k.note)}</td></tr>`).join("");
  return `
<section class="section"><div class="container">
  <div class="section-head"><span class="mono-label">AI OVERVIEW PERFORMANCE</span>
    <h2>Where the brand shows up in Google's AI, and the high-value queries it is missing.</h2></div>
  ${ctaLink(m, "See all queries we tested")}
  <div class="stats-bar">${stats.map((s) => `<div class="stat-card"><div class="lbl">${clean(s.lbl)}</div><div class="num">${clean(s.num)}</div><div class="sub">${clean(s.sub)}</div></div>`).join("")}</div>
  ${missed ? `<div style="margin-top:40px;"><div class="section-head"><span class="mono-label">HIGH-VALUE QUERIES WHERE THE BRAND RANKS BUT IS NOT QUOTED</span></div>
  <div class="tbl-wrap"><table><thead><tr><th style="width:42%">Query</th><th>Volume</th><th>Organic rank</th><th>What happens</th></tr></thead><tbody>${missed}</tbody></table></div></div>` : ""}
</div></section>`;
}

function coverage(m) {
  const c = m.analysis?.contentCoverage || {};
  // Each item is a string, often "Topic name (buyer intent)". Split topic from the parenthetical intent.
  const splitItem = (i) => {
    const s = typeof i === "string" ? i : i.topic || i.name || JSON.stringify(i);
    const mt = String(s).match(/^(.*?)\s*\(([^)]*)\)\s*$/);
    return { topic: mt ? mt[1].trim() : String(s).trim(), intent: mt ? mt[2].trim() : "" };
  };
  const rows = [
    ["strongPresence", "Owned", "yes"],
    ["partialPresence", "Partial", ""],
    ["invisible", "Invisible", "no"],
  ].flatMap(([key, status, cls]) =>
    arr(c[key]).map((i) => {
      const { topic, intent } = splitItem(i);
      return `<tr><td>${clean(topic)}</td><td class="${cls}">${status}</td><td>${clean(intent) || "&mdash;".replace("&mdash;", "")}</td></tr>`;
    })
  ).join("");
  const bj = c.buyerJourneyGaps || {};
  return `
<section class="section"><div class="container">
  <div class="section-head"><span class="mono-label">CONTENT AND ENTITY COVERAGE</span>
    <h2>The topics that matter to the brand, and where it shows up in AI answers today.</h2></div>
  ${ctaLink(m, "See the full query-by-query breakdown")}
  ${rows ? `<div class="tbl-wrap"><table><thead><tr><th style="width:48%">Topic</th><th>Presence in AI answers</th><th>Buyer intent</th></tr></thead><tbody>${rows}</tbody></table></div>` : ""}
  ${Object.keys(bj).length ? `<div class="callout good" style="margin-top:32px;"><div class="mono-label">Buyer-journey coverage</div>
    <div>${["problemAware", "solutionAware", "alternatives"].filter((k) => bj[k]).map((k) => `<p><strong>${k.replace(/([A-Z])/g, " $1").replace(/^./, (x) => x.toUpperCase())}.</strong> ${clean(bj[k])}</p>`).join("")}</div></div>` : ""}
</div></section>`;
}

function citations(m) {
  const c = m.analysis?.citationLandscape || {};
  const ext = arr(c.externalDomainsAioCites).map((d) =>
    `<tr><td>${clean(d.domain)}</td><td>${clean(d.pages)}</td><td>${clean(d.context)}</td></tr>`).join("");
  return `
<section class="section"><div class="container">
  <div class="section-head"><span class="mono-label">WHERE GOOGLE'S AI GETS ITS ANSWERS</span>
    <h2>The sources Google's AI cites in this category, and what it tells you about earning citations.</h2></div>
  ${ext ? `<div class="tbl-wrap"><table><thead><tr><th style="width:34%">Domain AI cites</th><th>Pages</th><th>Context</th></tr></thead><tbody>${ext}</tbody></table></div>` : ""}
  ${c.citationInsight ? `<div class="callout good" style="margin-top:28px;"><div class="mono-label">Reading</div><div>${clean(c.citationInsight)}</div></div>` : ""}
</div></section>`;
}

function peers(m) {
  const a = m.analysis?.aioRevealedPeers || {};
  const rows = arr(a.peers).map((p) =>
    `<tr><td>${clean(p.name)}</td><td>${clean(p.context)}</td></tr>`).join("");
  return `
<section class="dark-zone dark"><div class="container">
  <div class="section-head"><span class="mono-label">AI-REVEALED PEERS</span>
    <h2>The competitive set drawn by Google's AI itself. Observed, not chosen.</h2></div>
  ${ctaLink(m, "See which queries each peer won")}
  ${a.note ? `<p class="lede">${clean(a.note)}</p>` : ""}
  ${rows ? `<div class="tbl-wrap"><table><thead><tr><th style="width:26%">Peer</th><th>How AI frames it</th></tr></thead><tbody>${rows}</tbody></table></div>` : ""}
  ${a.keyObservation ? `<div class="card" style="margin-top:28px;"><div class="mono-label">Key observation</div><div>${clean(a.keyObservation)}</div></div>` : ""}
</div></section>`;
}

function roadmap(m) {
  const r = m.geoScore?.roadmap90Day || {};
  const sprints = [
    ["Month 1", "Days 1 to 30", r.sprint1_days1to30],
    ["Month 2", "Days 31 to 60", r.sprint2_days31to60],
    ["Month 3", "Days 61 to 90", r.sprint3_days61to90],
  ];
  return `
<section class="section"><div class="container">
  <div class="section-head"><span class="mono-label">90-DAY ROADMAP</span><h2>Three sprints from first wins to compounding category presence.</h2></div>
  <div class="grid grid-3">${sprints.map(([mo, days, items]) =>
    `<div class="sprint"><div class="num">${mo}${dot}${days}</div><ul>${arr(items).map((i) => `<li>${clean(typeof i === "string" ? i : i.task || i.action || JSON.stringify(i))}</li>`).join("")}</ul></div>`).join("")}</div>
</div></section>`;
}

// Tested-query log. Pulled from analysis.testedQueries (authored into the
// canonical) or, as a fallback, derived straight from the raw aio.results.
function queryRows(m) {
  let q = arr(m.analysis?.testedQueries);
  if (!q.length && m.aio && Array.isArray(m.aio.results)) {
    q = m.aio.results.map((r) => ({
      query: r.query, layer: r.layer, bucket: r.bucket, citedTop: arr(r.citedDomains).slice(0, 3),
    }));
  }
  return q;
}

// A jump-link CTA into the tested-queries table, shown in data-driven sections.
function ctaLink(m, text) {
  const n = queryRows(m).length;
  if (!n) return "";
  return `<p style="margin:36px 0;"><a href="#tested-queries" class="mono-label" style="display:inline-block;text-decoration:none;padding:15px 24px;border:1px solid currentColor;border-radius:6px;cursor:pointer;">${clean(text)} &rarr;</a></p>`;
}

const Q_BUCKET = {
  owned: ["Cited", "yes"],
  mentioned_not_cited: ["Named, not cited", ""],
  invisible: ["Absent", "no"],
  aio_pending: ["Pending", ""],
  no_aio: ["No AI answer", ""],
};

function testedQueries(m, brand) {
  const q = queryRows(m);
  if (!q.length) return "";
  const rows = q.map((r) => {
    const [label, cls] = Q_BUCKET[r.bucket] || [r.bucket, ""];
    return `<tr><td>${clean(r.query)}</td><td class="${cls}">${clean(label)}</td><td>${clean(arr(r.citedTop).join(", "))}</td></tr>`;
  }).join("");
  return `
<section class="section" id="tested-queries"><div class="container">
  <div class="section-head"><span class="mono-label">QUERIES WE TESTED</span>
    <h2>Every query we ran against Google's AI Overview, and what we found.</h2></div>
  <p class="lede">${q.length} queries across branded, positioning, and comparison intent. "Cited" means ${clean(brand)}'s own domain is a source in the AI answer. "Named, not cited" means the brand is mentioned but is not the source. "Absent" means the AI answered without it.</p>
  <div class="tbl-wrap"><table><thead><tr><th style="width:44%">Query</th><th>${clean(brand)} in the AI answer</th><th>Top sources cited</th></tr></thead><tbody>${rows}</tbody></table></div>
</div></section>`;
}

function footer(brand, m) {
  return `
<footer><div class="container">
  <div class="word">${clean(brand.toLowerCase())}.</div>
  <div class="meta-row">
    <div class="left">GEO AUDIT${dot}BRAND-ONLY${dot}${fmtDate(m.meta.completedAt).toUpperCase()}</div>
    <div class="right">PREPARED BY AUQ${dot}ANALYTICS@AUQ.IO</div>
  </div>
</div></footer>`;
}

// ---- main -------------------------------------------------------------------
function render(memory) {
  const brand = memory.geoScore?.brand || memory.analysis?.brand || memory.meta?.domain || "Brand";
  const body = [
    `<nav class="topnav"><div class="container"><a class="brand" href="https://auq.io">AUQ</a><div class="navmid mono-label"><a href="https://auq.io/geo-llm-optimization/">AUQ GEO</a><a href="https://auq.io/geo-analytics/">GEO Analytics</a><a href="https://auq.io/pricing/">Pricing</a><a href="https://auq.io/team/">Our Team</a></div><a class="btn-cta" href="https://auq.io/contact-us/">Contact Us</a></div></nav>`,
    hero(memory, brand),
    execSummary(memory, brand),
    identity(memory, brand),
    coverage(memory),
    performance(memory, brand),
    testedQueries(memory, brand),
    keyFindings(memory, brand),
    citations(memory),
    peers(memory),
    roadmap(memory),
    footer(brand, memory),
  ].join("\n");
  return `<!doctype html><html lang="en"><head><meta charset="utf-8">${GTM_HEAD}<meta name="viewport" content="width=device-width, initial-scale=1">
<title>${esc(brand)} GEO Audit, brand-only, by AUQ</title>
${FONTS}
<style>${CSS}</style></head><body>${GTM_BODY}${body}</body></html>`;
}

function loadRenderInput(input) {
  const stat = fs.existsSync(input) ? fs.statSync(input) : null;
  if (stat && stat.isDirectory()) {
    const canon = path.join(input, "canonical.json");
    const mem = path.join(input, "memory.json");
    const chosen = fs.existsSync(canon) ? canon : mem;
    const data = JSON.parse(fs.readFileSync(chosen, "utf8"));
    const idPath = path.join(input, "llm-identity.json");
    if (fs.existsSync(idPath) && !data.llmIdentity && !(data.analysis && data.analysis.llmIdentity)) {
      data.llmIdentity = JSON.parse(fs.readFileSync(idPath, "utf8"));
    }
    return data;
  }
  return JSON.parse(fs.readFileSync(input, "utf8"));
}

if (require.main === module) {
  const input = process.argv[2];
  const out = process.argv[3];
  if (!input || !out) { console.error("Usage: node render-roboflow.js <runDir|canonical.json|memory.json> <out.html>"); process.exit(1); }
  const memory = loadRenderInput(input);
  fs.writeFileSync(out, render(memory));
  console.log("Wrote", out, "(" + fs.statSync(out).size + " bytes) for", memory.meta?.domain);
}

module.exports = { render, loadRenderInput };
