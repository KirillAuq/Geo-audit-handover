#!/usr/bin/env node
// Live AIO measurement step (no Anthropic key; uses DataForSEO creds).
//
// Reads the live Google AI Overview for each positioning query, buckets the
// brand deterministically, and saves the result under memory key `aio`.
//
// Flow: the local Claude session derives the brand's themes from the `site`
// extraction and writes an identity.json, then runs this key-free script.
//
// Usage: node scripts/aio-read.js <domain> [identity.json]
// identity.json: { "brand": "...", "products": [...], "categories": [...], "competitors": [...] }
const path = require("path");
require("../src/load-env").config({ path: path.join(__dirname, "..", ".env") });

const fs = require("fs");
const { AgentMemory } = require("../src/agent-memory");
const { measure } = require("../src/aio-read");
const { progressHooks } = require("../src/run-progress");
const { inferBrandName } = require("../src/ahrefs-mcp");

(async () => {
  const domain = process.argv[2];
  const identityPath = process.argv[3];
  if (!domain) {
    console.error("usage: node scripts/aio-read.js <domain> [identity.json]");
    process.exit(1);
  }
  const identity = identityPath ? JSON.parse(fs.readFileSync(identityPath, "utf8")) : {};
  if (!identity.brand) identity.brand = inferBrandName(domain);

  const samples = Number(process.env.AIO_SAMPLES) || 2;
  const memory = await AgentMemory.create(domain);
  const out = await measure(domain, identity, { samples, ...progressHooks(memory, domain) });
  memory.set("aio", out);
  memory.merge("meta", { phase: "aio_measured", brand: identity.brand });
  await memory.save();

  console.log(`AIO measured -> runId ${memory.runId}  domain ${domain}`);
  console.log(`  queries: ${out.queryCount}  AIO trigger rate: ${out.aioTriggerRatePct}%`);
  console.log(`  buckets:`, out.counts);
  console.log(`  top AIO-revealed peers:`, out.topPeers.slice(0, 6).map((p) => `${p.domain}(${p.citations})`).join(", "));
  console.log(`  -> next: Claude (this session) reads .data/runs/${memory.runId}/memory.json (keys: site, aio), writes canonical JSON, then render-roboflow.js`);
})();
