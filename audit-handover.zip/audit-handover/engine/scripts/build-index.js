#!/usr/bin/env node
// Build a local index.html for a folder of rendered audit reports. No git, no
// network, no host. Cards are sorted by score descending.
//
// Usage: node scripts/build-index.js [outDir]
// Env:   GEO_AUDIT_OUT_DIR (used when outDir is omitted)
//        GEO_AUDIT_ENGINE_DIR (to locate .data/runs; defaults to this repo)
//
// Card data comes from each run's canonical.json, matched to a report by slug.
// If no canonical is found, the values are read back out of the rendered HTML,
// so an index can still be built from reports alone.
const fs = require("fs");
const path = require("path");

const ENGINE = process.env.GEO_AUDIT_ENGINE_DIR || path.join(__dirname, "..");
const OUT = path.resolve(process.argv[2] || process.env.GEO_AUDIT_OUT_DIR || path.join(ENGINE, "..", "audit-output"));

const esc = (s) => String(s == null ? "" : s).replace(/[&<>"]/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;" }[c]));
const slugOf = (domain) => String(domain || "").split(".")[0];

// ---- collect canonical.json, newest run per domain --------------------------
function canonicalsBySlug() {
  const runs = path.join(ENGINE, ".data", "runs");
  const bySlug = {};
  if (!fs.existsSync(runs)) return bySlug;
  for (const dir of fs.readdirSync(runs)) {
    const f = path.join(runs, dir, "canonical.json");
    if (!fs.existsSync(f)) continue;
    let c;
    try { c = JSON.parse(fs.readFileSync(f, "utf8")); } catch { continue; }
    const domain = c.meta?.domain;
    if (!domain) continue;
    const slug = slugOf(domain);
    const mtime = fs.statSync(f).mtimeMs;
    if (!bySlug[slug] || mtime > bySlug[slug]._mtime) {
      bySlug[slug] = {
        brand: c.geoScore?.brand || domain,
        domain,
        score: c.geoScore?.overallScore,
        band: c.geoScore?.band,
        _mtime: mtime,
      };
    }
  }
  return bySlug;
}

// ---- fallback: read the card values back out of a rendered report -----------
function fromHtml(file, slug) {
  const h = fs.readFileSync(file, "utf8");
  const pick = (re) => (h.match(re) || [])[1];
  const title = pick(/<title>([^<]*?)\s+GEO Audit/i);
  const score = pick(/<div class="big">\s*(\d+)\s*<\/div>/);
  const band = pick(/<div class="band"><span>([^<]*?)\s*band<\/span>/i);
  const domain = pick(/([a-z0-9-]+\.[a-z.]{2,})<\/div>/i);
  return { brand: title || slug, domain: domain || "", score: score ? Number(score) : null, band: band || "" };
}

function card(c) {
  const score = c.score == null ? "" : c.score;
  const band = c.band ? `${esc(c.band)} band` : "";
  return `<a class="card" href="${esc(c.slug)}.html"><div class="b">${esc(c.brand)}</div><div class="d">${esc(c.domain)}</div><div class="s"><span class="n">${esc(score)}</span><span class="band">${band}</span></div></a>`;
}

function main() {
  if (!fs.existsSync(OUT)) { console.error(`No such directory: ${OUT}`); process.exit(1); }
  const reports = fs.readdirSync(OUT).filter((f) => f.endsWith(".html") && f !== "index.html");
  if (!reports.length) { console.error(`No reports found in ${OUT}`); process.exit(1); }

  const canon = canonicalsBySlug();
  const cards = [];
  const noCanon = [];
  for (const f of reports.sort()) {
    const slug = f.replace(/\.html$/, "");
    let c = canon[slug];
    if (!c) { c = fromHtml(path.join(OUT, f), slug); noCanon.push(slug); }
    cards.push({ ...c, slug });
  }
  cards.sort((a, b) => (b.score ?? -1) - (a.score ?? -1) || a.brand.localeCompare(b.brand));

  const html = `<!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>AUQ GEO Audits</title><link rel="preconnect" href="https://fonts.googleapis.com"><link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600&family=JetBrains+Mono:wght@400;500&display=swap" rel="stylesheet"><style>*{box-sizing:border-box;margin:0}body{font-family:Inter,system-ui,sans-serif;background:#fafafa;color:#111;padding:80px 24px;max-width:980px;margin:0 auto}.ey{font-family:'JetBrains Mono',monospace;font-size:12px;letter-spacing:.12em;color:#6B7280;text-transform:uppercase}h1{font-size:48px;font-weight:600;letter-spacing:-.02em;margin:12px 0 8px}.sub{color:#6B7280;font-size:17px;margin-bottom:48px}.grid{display:grid;grid-template-columns:repeat(2,1fr);gap:18px}.card{display:block;text-decoration:none;color:inherit;border:1px solid #E5E7EB;border-radius:14px;padding:24px;background:#fff;transition:.15s}.card:hover{border-color:#2563EB;box-shadow:0 6px 24px rgba(37,99,235,.08);transform:translateY(-2px)}.b{font-size:22px;font-weight:600}.d{font-family:'JetBrains Mono',monospace;font-size:13px;color:#6B7280;margin:4px 0 18px}.s{display:flex;align-items:baseline;gap:10px}.n{font-size:40px;font-weight:600;color:#2563EB}.band{font-size:13px;color:#6B7280}footer{margin-top:56px;font-family:'JetBrains Mono',monospace;font-size:12px;color:#9CA3AF;letter-spacing:.08em}@media(max-width:700px){.grid{grid-template-columns:1fr}body{padding:48px 16px}h1{font-size:34px}}</style></head><body><div class="ey">GEO AUDITS · BRAND-ONLY</div><h1>AUQ GEO Audits</h1><p class="sub">How brands are described, positioned, and quoted inside Google's AI Overviews.</p><div class="grid">${cards.map(card).join("")}</div><footer>PREPARED BY AUQ · ANALYTICS@AUQ.IO</footer></body></html>`;

  const dest = path.join(OUT, "index.html");
  fs.writeFileSync(dest, html);
  console.log(`Wrote ${dest} (${cards.length} audits)`);
  if (noCanon.length) console.log(`  read from HTML, no canonical.json found: ${noCanon.join(", ")}`);
}

if (require.main === module) main();
module.exports = { main };
