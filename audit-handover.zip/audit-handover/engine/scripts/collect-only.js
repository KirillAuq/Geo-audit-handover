#!/usr/bin/env node
// Collect-only audit step (key-free of Anthropic): site fetch + live Google AI
// Overview measurement (DataForSEO), saved to .data/runs/<id>/memory.json. Does
// NOT call the Anthropic key. Analysis/scoring is then done by Claude in the
// Claude Code session, and the page is rendered with render-roboflow.js — so a
// full report needs no metered API key.
//
// Positioning queries are driven by the brand's themes. For full coverage,
// derive an identity.json from the site first (brand, products, categories,
// competitors) and pass it. Without one, only branded queries are measured.
//
// Usage: node scripts/collect-only.js <domain> [identity.json]
const path = require("path");
require("../src/load-env").config({ path: path.join(__dirname, "..", ".env") });

const fs = require("fs");
const { AgentMemory } = require("../src/agent-memory");
const { extractSiteIdentity } = require("../src/site-fetch");
const { measure } = require("../src/aio-read");
const { progressHooks } = require("../src/run-progress");
const { inferBrandName } = require("../src/ahrefs-mcp");

(async () => {
  const domain = process.argv[2];
  const identityPath = process.argv[3];
  if (!domain) {
    console.error("usage: node scripts/collect-only.js <domain> [identity.json]");
    process.exit(1);
  }

  const identity = identityPath ? JSON.parse(fs.readFileSync(identityPath, "utf8")) : {};
  if (!identity.brand) identity.brand = inferBrandName(domain);
  const themed = Boolean(
    (identity.products && identity.products.length) || (identity.categories && identity.categories.length)
  );

  const samples = Number(process.env.AIO_SAMPLES) || 2;
  const memory = await AgentMemory.create(domain);
  memory.set("identity", identity);
  const [site, aio] = await Promise.all([
    extractSiteIdentity(domain),
    measure(domain, identity, { samples, ...progressHooks(memory, domain) }),
  ]);
  memory.set("site", site);
  memory.set("aio", aio);
  memory.set("identity", identity);
  memory.merge("meta", { phase: "collected", brand: identity.brand, themed });
  await memory.save();

  console.log(`Collected (no Anthropic key) -> runId ${memory.runId}  domain ${domain}`);
  console.log(`  AIO queries: ${aio.queryCount}  samples/query: ${samples}  trigger rate: ${aio.aioTriggerRatePct}%`);
  console.log(`  buckets:`, aio.counts);
  console.log(`  top AIO-revealed peers:`, aio.topPeers.slice(0, 6).map((p) => `${p.domain}(${p.citations})`).join(", "));
  if (!themed) {
    console.log(`  ! branded-only (no themes provided). For full coverage, derive an identity.json from the site and re-run:`);
    console.log(`      node scripts/collect-only.js ${domain} identity.json`);
  }
  console.log(`  -> next: Claude (this session) reads .data/runs/${memory.runId}/memory.json (keys: site, aio), writes canonical JSON, then render-roboflow.js`);
})();
