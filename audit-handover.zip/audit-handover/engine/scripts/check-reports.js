#!/usr/bin/env node
// Check rendered reports against the house writing rules.
//
// Usage: node scripts/check-reports.js [outDir]
// Env:   GEO_AUDIT_OUT_DIR (used when outDir is omitted)
//        GEO_AUDIT_GTM_ID  (set to "off" when the reports were rendered without a tag)
//
// Checks:
//   - no em dashes, no en dashes, anywhere in the visible text
//   - no third-party tool names in the report's own prose
//     (case-insensitive: "Semrush" and "SEMrush" both fail)
//   - the analytics tag matches the render setting: present by default, and
//     absent when GEO_AUDIT_GTM_ID=off, so a no-tag client report passes and a
//     tag that leaked into one fails
//
// EXEMPT from the tool-name check, because they are measured data rather than
// the report naming our tooling:
//   - the sections WHERE GOOGLE'S AI GETS ITS ANSWERS / AI-REVEALED PEERS /
//     QUERIES WE TESTED
//   - domain-shaped tokens anywhere (semrush.com, enterprise.semrush.com), which
//     only appear because Google's AI cited them
//   - <blockquote> bodies, which quote the brand's site or Google's AI verbatim
// The dash rules still apply to the whole document.
const fs = require("fs");
const path = require("path");

const TOOL_NAMES = ["ahrefs", "brand radar", "dataforseo", "semrush", "moz", "similarweb", "sistrix"];
const DATA_SECTIONS = ["WHERE GOOGLE'S AI GETS ITS ANSWERS", "AI-REVEALED PEERS", "QUERIES WE TESTED"];
const GTM_OFF = String(process.env.GEO_AUDIT_GTM_ID ?? "").trim().toLowerCase() === "off";

function targetDir() {
  const args = process.argv.slice(2).filter((a) => !a.startsWith("-"));
  if (args.length) return path.resolve(args[0]);
  const env = process.env.GEO_AUDIT_OUT_DIR;
  if (env) return path.resolve(env.replace(/^~/, process.env.HOME || "~"));
  return process.cwd();
}

// Drop style/script bodies, then tags. CSS carries vendor prefixes like -moz-
// and font stacks that would otherwise read as tool names.
function visibleText(html) {
  return html
    .replace(/<style\b[\s\S]*?<\/style>/gi, " ")
    .replace(/<script\b[\s\S]*?<\/script>/gi, " ")
    .replace(/<!--[\s\S]*?-->/g, " ")
    .replace(/<[^>]+>/g, " ");
}

function stripDataSections(html) {
  const out = [];
  let pos = 0;
  const re = /<section\b/g;
  let m;
  while ((m = re.exec(html)) !== null) {
    const start = m.index;
    const nxt = html.indexOf("<section", start + 1);
    const end = nxt === -1 ? html.length : nxt;
    const chunk = html.slice(start, end);
    const label = chunk.match(/mono-label">([^<]+)</);
    if (label && DATA_SECTIONS.includes(label[1].trim().toUpperCase())) {
      out.push(html.slice(pos, start));
      pos = end;
    }
  }
  out.push(html.slice(pos));
  return out.join("");
}

// Remove the other measured-data carriers: verbatim quotes, and any token shaped
// like a domain, which in a report is always a cited source.
function stripMeasuredData(html) {
  return visibleText(stripDataSections(html).replace(/<blockquote\b[\s\S]*?<\/blockquote>/gi, " "))
    .replace(/\b(?:[a-z0-9-]+\.)+[a-z]{2,}\b/gi, " ");
}

const countOf = (s, ch) => s.split(ch).length - 1;

function check(file) {
  const html = fs.readFileSync(file, "utf8");
  const problems = [];

  const all = visibleText(html);
  if (countOf(all, "—")) problems.push(`em dash x${countOf(all, "—")}`);
  if (countOf(all, "–")) problems.push(`en dash x${countOf(all, "–")}`);

  const prose = stripMeasuredData(html);
  for (const name of TOOL_NAMES) {
    const hits = prose.match(new RegExp(`\\b${name.replace(/[.*+?^${}()|[\]\\]/g, "\\$&")}\\b`, "gi"));
    if (hits) problems.push(`"${name}" x${hits.length}`);
  }

  const hasTag = html.includes("googletagmanager.com");
  if (GTM_OFF && hasTag) {
    problems.push("analytics tag present, but GEO_AUDIT_GTM_ID=off (re-render with it set)");
  } else if (!GTM_OFF && !hasTag) {
    problems.push("no analytics tag (rendered with GEO_AUDIT_GTM_ID=off? then run this check with it set too)");
  }

  return problems;
}

function main() {
  const dir = targetDir();
  const files = fs.readdirSync(dir).filter((f) => f.endsWith(".html") && f !== "index.html").sort();
  if (!files.length) {
    console.log(`No reports found in ${dir}`);
    return 2;
  }
  let bad = 0;
  for (const f of files) {
    const problems = check(path.join(dir, f));
    if (problems.length) bad++;
    console.log(`${problems.length ? "FAIL" : "ok  "} ${f}${problems.length ? "  " + problems.join("; ") : ""}`);
  }
  console.log("-".repeat(52));
  console.log(`analytics tag expected: ${GTM_OFF ? "no (GEO_AUDIT_GTM_ID=off)" : "yes"}`);
  if (bad) {
    console.log(`${bad} of ${files.length} need fixing. Correct the source strings and re-render.`);
    return 1;
  }
  console.log(`All ${files.length} clean.`);
  return 0;
}

if (require.main === module) process.exit(main());
