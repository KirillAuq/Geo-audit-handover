#!/usr/bin/env node
// One full audit in a single process: site-fetch + live AIO measurement ->
// deterministic canonical -> rendered HTML. The batch unit. No Anthropic key.
//
// Usage: node scripts/audit-one.js <domain> <identity.json|-> <out.html>
// Env:   AIO_SAMPLES (default 2), GEO_AUDIT_REQUEST_TIMEOUT_SEC (default 90)
//
// Prints one progress line per query and saves partial results to memory.json
// as it goes. The final status line is always the last line printed.
const path = require("path");
require("../src/load-env").config({ path: path.join(__dirname, "..", ".env") });

const fs = require("fs");
const { AgentMemory } = require("../src/agent-memory");
const { extractSiteIdentity } = require("../src/site-fetch");
const { measure } = require("../src/aio-read");
const { progressHooks } = require("../src/run-progress");
const { inferBrandName } = require("../src/ahrefs-mcp");
const { build } = require("./normalize_aio");
const { render } = require("./render-roboflow");

const domain = process.argv[2];
const identityPath = process.argv[3];
const outHtml = process.argv[4];

(async () => {
  if (!domain || !outHtml) {
    console.error("usage: node scripts/audit-one.js <domain> <identity.json|-> <out.html>");
    process.exit(1);
  }
  const samples = Number(process.env.AIO_SAMPLES) || 2;
  const identity = identityPath && identityPath !== "-" ? JSON.parse(fs.readFileSync(identityPath, "utf8")) : {};
  if (!identity.brand) identity.brand = inferBrandName(domain);

  const memory = await AgentMemory.create(domain);
  memory.set("identity", identity);
  const [site, aio] = await Promise.all([
    // Site fetch is only used for the report's differentiator text; a blocked or
    // slow site must not fail the audit (themes come from identity.json).
    extractSiteIdentity(domain).catch((e) => ({ domain, pages: [], error: String((e && e.message) || e) })),
    measure(domain, identity, { samples, ...progressHooks(memory, domain) }),
  ]);
  memory.set("site", site);
  memory.set("aio", aio);
  memory.set("identity", identity);
  memory.merge("meta", { phase: "collected", brand: identity.brand, completedAt: new Date().toISOString() });
  await memory.save();

  const canon = build(memory.data);
  const canonPath = path.join(__dirname, "..", ".data", "runs", memory.runId, "canonical.json");
  fs.writeFileSync(canonPath, JSON.stringify(canon, null, 2));
  fs.mkdirSync(path.dirname(outHtml), { recursive: true });
  fs.writeFileSync(outHtml, render(canon));

  const p = canon.analysis.aioPerformance;
  console.log(`[${domain}] runId ${memory.runId} | score ${canon.geoScore.overallScore} ${canon.geoScore.band} | trigger ${p.aioTriggerRatePct} | cited ${p.brandCitedInAioCount}/${p.aioTriggerCount} | -> ${outHtml}`);
})().catch((e) => { console.error(`FAILED ${domain}: ${e.message}`); process.exit(1); });
