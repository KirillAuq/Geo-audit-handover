#!/usr/bin/env node
// Deterministic canonical builder: memory.json (site + aio) -> canonical.json
// (meta + geoScore + analysis + testedQueries). No API calls, no LLM. Computes
// the score and buckets from the live AIO reads and templates the narrative, so
// a batch of audits can be produced consistently from raw measurement.
//
// Usage: node scripts/normalize_aio.js <runDir|memory.json> <out.json>
const fs = require("fs");
const path = require("path");
const { inferBrandName } = require("../src/ahrefs-mcp");
const { buildFacts } = require("../src/insights");

const MODS = ["solutions", "software", "platform", "tools", "vendors", "providers", "comparison", "alternatives"];
const cap = (s) => String(s || "").replace(/\b\w/g, (c) => c.toUpperCase());
const pctRound = (n, d) => (d ? Math.round((n / d) * 100) : 0);

function findAio(o) {
  if (o && typeof o === "object") {
    if (Array.isArray(o.results) && o.counts) return o;
    for (const k in o) { const r = findAio(o[k]); if (r) return r; }
  }
  return null;
}

function themeRoot(q) {
  let s = String(q).toLowerCase().trim();
  s = s.replace(/^(best|top)\s+/, "").replace(/^what is\s+/, "").replace(/^how does\s+/, "").replace(/\s+work$/, "");
  s = s.replace(/^alternatives to\s+/, "").replace(/\s+vs\s+.*$/, "");
  s = s.replace(new RegExp("\\s+(" + MODS.join("|") + ")$"), "").replace(/\s+(reviews|pricing)$/, "");
  return s.trim();
}

function build(memory) {
  const aio = findAio(memory) || { results: [], counts: {}, topPeers: [], queryCount: 0, aioTriggerRatePct: 0 };
  const domain = memory.meta?.domain || aio.domain || "brand.com";
  const brand = memory.meta?.brand || memory.identity?.brand || inferBrandName(domain);
  const identity = memory.identity || {};
  const results = aio.results || [];
  const c = aio.counts || {};
  const qc = aio.queryCount || results.length;
  const owned = c.owned || 0, mentioned = c.mentioned_not_cited || 0, invisible = c.invisible || 0, noAio = c.no_aio || 0;
  const aioFired = qc - noAio;

  // ---- theme rollup for content coverage --------------------------------
  // Prefer grouping by the brand's own identity categories (clean labels, no
  // dupes); fall back to stripping modifiers off the query when no identity.
  const cats = [...(identity.categories || []), ...(identity.products || [])]
    .map((s) => String(s).toLowerCase()).filter(Boolean).sort((a, b) => b.length - a.length);
  const brandLc = String(brand).toLowerCase();
  const themeOf = (r) => {
    if (r.layer === "branded") return brandLc;
    const ql = String(r.query).toLowerCase();
    for (const cat of cats) if (ql.includes(cat)) return cat;
    if (r.layer === "comparison") return brandLc;
    return themeRoot(r.query);
  };
  const themes = {};
  for (const r of results) {
    const t = themeOf(r);
    (themes[t] = themes[t] || { owned: 0, mentioned_not_cited: 0, invisible: 0, no_aio: 0, aio_pending: 0, layer: r.layer })[r.bucket]++;
  }
  const strong = [], partial = [], invis = [];
  for (const [t, b] of Object.entries(themes)) {
    const label = `${cap(t)} (${b.layer || "positioning"})`;
    const o = b.owned, m = b.mentioned_not_cited, i = b.invisible;
    if (o >= Math.max(m, i) && o > 0) strong.push(label);
    else if (i >= Math.max(o, m) && i > 0) invis.push(label);
    else if (m > 0) partial.push(label);
    else if (o > 0) strong.push(label);
  }

  // ---- peers / citation landscape ---------------------------------------
  const peers = (aio.topPeers || []).filter((p) => !p.domain.includes(domain.split(".")[0]));
  const ext = peers.slice(0, 10).map((p) => ({
    domain: p.domain, pages: p.citations, context: `Cited on ${p.citations} of the queries we tested.`,
  }));

  // ---- scoring -----------------------------------------------------------
  const inclusion = pctRound(owned, aioFired);
  const category = pctRound(owned + mentioned, aioFired);
  const themeCount = Object.keys(themes).length || 1;
  const presentThemes = Object.values(themes).filter((b) => b.owned > 0 || b.mentioned_not_cited > 0).length;
  // Theme presence only: a theme counts when any of its queries is owned or
  // named. This is not a reading of LLM answer text. The separate LLM identity
  // check must not change these weights or this formula.
  const identityScore = pctRound(presentThemes, themeCount);
  const breadth = pctRound(strong.length, themeCount);
  const trigger = pctRound(aioFired, qc);
  // Weighted index. No branded component. Branded queries are excluded from the
  // query set, so the score reflects category and decision-stage presence only.
  const overall = Math.round(0.35 * inclusion + 0.25 * category + 0.20 * identityScore + 0.20 * breadth);
  const band = overall < 26 ? "Absent" : overall < 51 ? "Low" : overall < 76 ? "Competitive" : "Dominant";

  const topInvisible = invis.slice(0, 3).map((s) => s.replace(/\s*\(.*\)$/, ""));
  const topOwned = strong.slice(0, 3).map((s) => s.replace(/\s*\(.*\)$/, ""));
  const homepage = (memory.site?.pages?.[0]?.text || "").replace(/\s+/g, " ").slice(0, 240).trim();

  const canon = {
    meta: { domain, completedAt: memory.meta?.completedAt || memory.meta?.fetchedAt || "" },
    geoScore: {
      brand,
      overallScore: overall,
      band,
      bandDescription: `${brand} is cited in ${owned} of ${aioFired} AI answers. ${topOwned.length ? "It shows up on " + topOwned.join(", ") + "." : ""} ${topInvisible.length ? "It is absent on " + topInvisible.join(", ") + "." : ""}`.trim(),
      // Only the four components that carry weight in overallScore are listed, so
      // the breakdown a client reads reconciles with the total. Order matches
      // descending weight. Trigger rate is still reported, under aioPerformance.
      components: [
        { label: "Your pages being quoted", weightPct: 35, scoreOutOf100: inclusion },
        { label: "Inclusion in category answers", weightPct: 25, scoreOutOf100: category },
        { label: "How AI describes the brand", weightPct: 20, scoreOutOf100: identityScore },
        { label: "Topic coverage breadth", weightPct: 20, scoreOutOf100: breadth },
      ],
      topLeverageMoves: [
        { move: topInvisible[0] ? `Win presence on ${topInvisible[0]}` : "Earn citations on decision-stage queries", impact: "high", effort: "medium", timeframe: "30 to 60 days" },
        { move: "Convert named-not-cited queries into citations", impact: "medium", effort: "low", timeframe: "0 to 30 days" },
        { move: "Earn placement in the third-party listicles AI cites", impact: "high", effort: "medium", timeframe: "30 to 90 days" },
      ],
      roadmap90Day: {
        sprint1_days1to30: [`Publish solution and comparison pages for ${topInvisible.join(", ") || "the invisible themes"}.`, "Build linkable comparison assets so AI Overviews can cite the brand's own domain."],
        sprint2_days31to60: ["Earn placement in third-party best-of listicles and review sites the AI cites.", "Seed community and review presence where AI Overviews pull trust signals."],
        sprint3_days61to90: ["Expand owned comparison content across decision-stage queries.", "Re-audit to confirm invisible themes move to cited and track citation share."],
      },
      successMetrics: [
        { metric: "AI visibility score", baseline: `${overall} / 100`, target90Day: `${Math.min(overall + 12, 90)} / 100`, cadence: "Monthly" },
        { metric: "Citation rate when AI answers", baseline: `${inclusion}%`, target90Day: `${Math.min(inclusion + 15, 90)}%`, cadence: "Monthly" },
        { metric: "Invisible themes converted to cited", baseline: `0 of ${invis.length}`, target90Day: `${Math.ceil(invis.length / 2)} of ${invis.length}`, cadence: "Monthly" },
      ],
    },
    analysis: {
      brand,
      identityGap: {
        brandCategory: identity.categories?.length ? cap(identity.categories[0]) : "Software vendor",
        brandSelfDescription: homepage || `${brand} positions itself around ${(identity.categories || []).join(", ") || "its product"}.`,
        brandDifferentiators: [...(identity.products || []), ...(identity.categories || [])].slice(0, 4).map(cap),
        aioPerceivedCategory: topOwned.length ? `Recognized in AI answers for ${topOwned.join(", ")}` : "Limited AI Overview presence",
        aioDescriptions: [
          topOwned.length ? `Cited as a provider on ${topOwned.join(", ")} queries.` : `Rarely cited as a source in AI answers.`,
          ext.length ? `Appears alongside ${ext.slice(0, 3).map((d) => d.domain).join(", ")}.` : "",
        ].filter(Boolean),
        aioStrengths: topOwned.map(cap),
        aioGaps: [...topInvisible.map(cap), "Cited source on vendor and comparison queries"],
        aioCategoryMisalignment: `${brand} presents as ${(identity.categories || []).join(", ") || "its category"}. AI Overviews cite it on ${topOwned.join(", ") || "few queries"} and it is absent on ${topInvisible.join(", ") || "several decision-stage queries"}.`,
      },
      aioPerformance: {
        trackedKeywords: qc,
        aioTriggerCount: aioFired,
        aioTriggerRatePct: `${trigger}%`,
        brandCitedInAioCount: owned,
        brandCitationRatePct: `${inclusion}%`,
        brandCitationRate: aioFired ? owned / aioFired : 0,
        mentionsTotal: owned + mentioned,
        brandPositionWhenCited: "as a listed provider, rarely the lead source",
        aioAppearanceNotes: `${brand} is cited in ${owned} of the ${aioFired} AI answers we triggered.`,
      },
      contentCoverage: {
        strongPresence: strong,
        partialPresence: partial,
        invisible: invis,
        buyerJourneyGaps: {
          problemAware: `Overview queries: ${brand} appears on ${strong.length} of ${themeCount} themes.`,
          solutionAware: `Owned on ${topOwned.join(", ") || "few"}; absent on ${topInvisible.join(", ") || "none"}.`,
          alternatives: `${mentioned} themes name the brand without citing it; ${invisible} queries answer without it at all.`,
        },
      },
      citationLandscape: {
        externalDomainsAioCites: ext,
        citationInsight: `Independent listicles, communities, and rival explainers win the citations ${brand} is missing. Earning AI citation on the invisible themes means placement on those third-party pages, not only owning its own glossary.`,
      },
      aioRevealedPeers: {
        note: `Brands and domains Google's AI cites in place of ${brand} on the queries where it is absent. Observed, not chosen.`,
        peers: peers.slice(0, 8).map((p) => ({ name: p.domain, context: `Cited on ${p.citations} of the tested queries.` })),
        keyObservation: ext[0] ? `${ext[0].domain} is the most-cited source across the queries ${brand} is missing.` : "",
      },
      testedQueries: results.map((r) => ({ query: r.query, layer: r.layer, bucket: r.bucket, citedTop: (r.citedDomains || []).slice(0, 3) })),
    },
  };
  // Grounding for the "What it found" and "Pitch" chat write-up. Not rendered.
  canon.analysis.insightFacts = buildFacts(memory, canon);
  return canon;
}

if (require.main === module) {
  const input = process.argv[2], out = process.argv[3];
  if (!input || !out) { console.error("Usage: node normalize_aio.js <runDir|memory.json> <out.json>"); process.exit(1); }
  const mPath = input.endsWith(".json") ? input : path.join(input, "memory.json");
  const canon = build(JSON.parse(fs.readFileSync(mPath, "utf8")));
  fs.writeFileSync(out, JSON.stringify(canon, null, 2));
  console.log(`Wrote ${out} | ${canon.geoScore.brand} score ${canon.geoScore.overallScore} (${canon.geoScore.band}) | ${canon.analysis.testedQueries.length} queries`);
}

module.exports = { build };
