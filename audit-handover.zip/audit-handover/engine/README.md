# GEO Audit Workflow

> **Scope note.** This file documents the optional web app (landing page plus the
> `/app` workflow UI) and its Vercel deployment. The audit pipeline itself is
> local and does not publish anywhere. For how audits are actually run, see
> `../geo-audit-handover/`.

Local web workflow for the **v1 brand-only GEO audit**. An agent follows `GEO-Audit-Spec-v1-Brand-Only.md` and the operational runbook in `Audit-SKILL.md`, uses **short-term run memory** on disk, and produces an **HTML report** (no hardcoded JSON schema).

## Flow

1. User submits a domain.
2. Server creates a run under `.data/runs/{runId}/memory.json`.
3. **Collect:** homepage/site pages + Ahrefs (Site Explorer + Brand Radar, including AI responses).
4. **Analysis agent:** Claude with `memory_read` / `memory_write` tools stores `promptSet`, `analysis`, `geoScore`, and notes.
5. **Report agent:** Claude reads memory and outputs HTML matching the spec’s 10 sections.
6. Browser shows the wrapped report; memory persists for inspection or re-runs.

## Setup

```bash
cp .env.example .env
# GEO_AUDIT_AHREFS_MCP_URL, GEO_AUDIT_AHREFS_MCP_KEY
# GEO_AUDIT_CLAUDE_API_KEY, GEO_AUDIT_CLAUDE_MODEL (optional)

npm install
npm start
# Landing:  http://localhost:3000/
# Audit app: http://localhost:3000/app
```

## Deploy (Vercel)

| URL | Page |
|-----|------|
| `/` | Marketing landing (lead form, sample report screenshots) |
| `/app` | Internal GEO audit workflow (domain → HTML report) |
| `POST /audit` | Audit API (`api/audit.js`, max 5 min on Pro — full runs need local `npm start`) |

**Note:** Do not use `api/index.js` on Vercel — it shadows `public/index.html` and breaks `/`.

Production: **https://geo-audit-mauve.vercel.app/**

After pushing, Vercel redeploys automatically. In the Vercel project **Settings → Environment Variables**, add the same `GEO_AUDIT_*` keys as in `.env` (Production and Preview). Without them, audits fail at runtime.

Run data is written to `/tmp` on Vercel (ephemeral per invocation).
```

CLI (same pipeline):

```bash
node scripts/run-audit.js microblink.com
```

## Memory keys (typical)

| Key | Contents |
|-----|----------|
| `meta` | domain, brandName, phase, timestamps |
| `spec`, `runbook`, `methodology`, `ahrefsNotes` | audit directions (split for smaller tool reads) |
| `site` | fetched page text (homepage, about, etc.) |
| `ahrefs` | summarized metrics + citations |
| `ahrefsRaw` | full Ahrefs payloads |
| `promptSet` | 20–40 prompts (agent-generated) |
| `analysis` | identity gap, performance, peers, etc. |
| `geoScore` | composite score + band |
| `notes` | working notes array |
| `reportHtml` | final HTML body |

## Notes

- Deliverable is **HTML** in the lead magnet, not `.docx` (spec still describes docx for manual/Cowork runs).
- Ahrefs field names vary by account; adjust `collectAhrefsData()` in `src/ahrefs-mcp.js` if pulls fail.
- Large domains may need higher `max_tokens` in `src/audit-agent.js`.
