// AUQ-branded, self-contained stylesheet for GEO audit reports.
// Inlined into every report so the page is styled anywhere it is hosted
// (localhost, GitHub Pages, email preview) without an external CSS request.
//
// The server template emits stable wrapper classes (.report-body, .card,
// .title-block, .executive-summary, .report-container, .report-meta,
// .back-link). The audit *body* is agent-generated and its inner class names
// vary run to run, so this sheet leans on base-element styling plus graceful
// handling of BOTH observed score-callout variants:
//   - .score-callout > .score-number + .score-label(div > strong + p)
//   - .geo-score-callout > .score-label(span) + .score-value + .score-note
const REPORT_CSS = `
:root{
  --c-ink:#010120;--c-bg:#ffffff;--c-paper:#f6f6f9;
  --c-magenta:#ef2cc1;--c-orange:#fc4c02;--c-lavender:#bdbbff;--c-indigo:#5a55c9;--c-green:#097a3f;
  --c-border:rgba(1,1,32,.10);--c-muted:rgba(1,1,32,.58);
  --shadow:0 4px 14px rgba(1,1,32,.07);--shadow-lg:0 16px 40px rgba(1,1,32,.10);
  --r:14px;--r-sm:7px;
  --f-display:"Inter","Helvetica Neue",Arial,sans-serif;
  --f-mono:"JetBrains Mono",ui-monospace,Menlo,monospace;
}
*{box-sizing:border-box;margin:0;padding:0}
html{scroll-behavior:smooth}
body{font-family:var(--f-display);font-size:16px;line-height:1.5;letter-spacing:-.011em;color:var(--c-ink);background:var(--c-paper);-webkit-font-smoothing:antialiased;-moz-osx-font-smoothing:grayscale}

.container,.report-container{max-width:940px;margin:0 auto;padding:0 24px}
.report-page .report-container{margin:44px auto;padding:0 24px 90px}
.back-link{display:inline-block;margin-bottom:18px;font-family:var(--f-mono);font-size:12px;text-transform:uppercase;letter-spacing:.1em;color:var(--c-muted);text-decoration:none}
.back-link:hover{color:var(--c-magenta)}
.report-meta,.muted.report-meta{font-family:var(--f-mono);font-size:11px;text-transform:uppercase;letter-spacing:.12em;color:var(--c-muted);margin-bottom:22px}
.muted{color:var(--c-muted)}

.report-body{display:flex;flex-direction:column;gap:22px}

/* cards */
.card,.report-body>section{background:var(--c-bg);border:1px solid var(--c-border);border-radius:var(--r);padding:38px;box-shadow:var(--shadow)}

/* title block (dark, gradient wash) */
.title-block{background:var(--c-ink);color:#fff;border:none;position:relative;overflow:hidden}
.title-block::before{content:"";position:absolute;width:560px;height:560px;top:-240px;right:-170px;background:radial-gradient(circle at 30% 30%,rgba(239,44,193,.40),transparent 60%),radial-gradient(circle at 70% 70%,rgba(189,187,255,.45),transparent 65%);filter:blur(55px);pointer-events:none}
.title-block>*{position:relative;z-index:1}
.title-block h1{color:#fff;margin-bottom:24px;max-width:22ch}

/* meta rows: .meta-grid/.meta-item and .meta-list/li */
.meta-grid,.meta-list{list-style:none;display:grid;grid-template-columns:repeat(auto-fit,minmax(210px,1fr));gap:12px 28px;padding:0;margin:0}
.meta-item,.meta-list li{font-family:var(--f-mono);font-size:12px;letter-spacing:.01em;color:rgba(255,255,255,.74);line-height:1.5;margin:0}

/* headings + text */
h1{font-size:40px;font-weight:600;line-height:1.05;letter-spacing:-.03em}
h2{font-size:26px;font-weight:600;line-height:1.15;letter-spacing:-.02em;margin-bottom:14px}
h3{font-size:17px;font-weight:600;line-height:1.3;letter-spacing:-.01em;margin:22px 0 10px}
p{font-size:15.5px;line-height:1.62;color:rgba(1,1,32,.82);margin-bottom:12px}
p:last-child{margin-bottom:0}
strong{font-weight:600}
a{color:var(--c-indigo)}

/* score callouts — both observed variants */
.score-callout,.geo-score-callout{display:flex;align-items:center;flex-wrap:wrap;gap:10px 28px;background:linear-gradient(135deg,rgba(239,44,193,.05),rgba(189,187,255,.12));border:1px solid var(--c-border);border-radius:var(--r);padding:28px 32px;margin:20px 0 24px}
.score-number,.score-value{font-size:92px;font-weight:600;line-height:.9;letter-spacing:-.04em;background:linear-gradient(135deg,var(--c-magenta),var(--c-lavender));-webkit-background-clip:text;background-clip:text;-webkit-text-fill-color:transparent;flex:none}
/* variant A: .score-label is a div with band <strong> + note <p> */
.score-callout .score-label{display:flex;flex-direction:column;gap:8px}
.score-callout .score-label strong{font-family:var(--f-mono);font-size:12px;font-weight:600;text-transform:uppercase;letter-spacing:.1em;color:var(--c-indigo);background:rgba(189,187,255,.22);border:1px solid rgba(189,187,255,.45);border-radius:var(--r-sm);padding:6px 12px;width:max-content}
.score-callout .score-label p{font-size:14px;color:var(--c-muted);margin:0}
/* variant B: span label + value + note, stacked */
.geo-score-callout{flex-direction:column;align-items:flex-start;gap:6px}
.geo-score-callout .score-label{font-family:var(--f-mono);font-size:11px;text-transform:uppercase;letter-spacing:.12em;color:var(--c-muted);order:1}
.geo-score-callout .score-value{order:2}
.geo-score-callout .score-note{font-size:14px;color:var(--c-muted);order:3;max-width:72ch}

/* findings + moves: .findings-list, .moves-list, .findings>ul, .top-moves>ul */
.findings-list,.moves-list,.findings>ul,.top-moves>ul{list-style:none;padding:0;margin:14px 0 0;display:grid;gap:14px}
.findings-list li,.moves-list li,.findings>ul>li,.top-moves>ul>li{border:1px solid var(--c-border);border-radius:var(--r-sm);padding:18px 20px;background:var(--c-bg);font-size:15px;line-height:1.55;box-shadow:var(--shadow);margin:0}
.findings-list li strong,.moves-list li strong,.findings li strong,.top-moves li strong{display:block;margin-bottom:5px;color:var(--c-ink)}

/* generic lists */
ul:not(.findings-list):not(.moves-list):not(.meta-list){padding-left:20px;margin:10px 0}
ul:not(.findings-list):not(.moves-list):not(.meta-list) li{margin:6px 0;font-size:15px;line-height:1.55}

/* tables */
table{width:100%;border-collapse:collapse;font-size:13.5px;margin:14px 0;border:1px solid var(--c-border);border-radius:var(--r-sm);overflow:hidden}
thead th{background:var(--c-ink);color:#fff;text-align:left;padding:12px 14px;font-family:var(--f-mono);font-size:10.5px;font-weight:600;text-transform:uppercase;letter-spacing:.07em}
tbody td{padding:11px 14px;border-top:1px solid var(--c-border);vertical-align:top;line-height:1.45}
tbody tr:nth-child(even) td{background:rgba(1,1,32,.025)}

/* quotes, warnings, fallback */
blockquote{border-left:3px solid var(--c-magenta);padding:6px 0 6px 20px;margin:14px 0;font-style:italic;font-size:16px;line-height:1.5;color:rgba(1,1,32,.82)}
.report-warnings{border-color:rgba(252,76,2,.3);background:rgba(252,76,2,.05)}
.memory-dump{white-space:pre-wrap;font-family:var(--f-mono);font-size:12px;background:rgba(1,1,32,.04);padding:14px;border-radius:var(--r-sm);overflow-x:auto}

@media(max-width:640px){
  .card,.report-body>section{padding:24px}
  h1{font-size:30px}h2{font-size:22px}
  .score-callout{flex-direction:column;align-items:flex-start;gap:14px}
  .score-number,.score-value{font-size:70px}
}`;

// Full <head> style block: preconnect + Google Fonts + inlined CSS.
const REPORT_STYLE_HEAD = `<link rel="preconnect" href="https://fonts.googleapis.com" />
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin />
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600&family=JetBrains+Mono:wght@400;500;600&display=swap" rel="stylesheet" />
    <style>${REPORT_CSS}</style>`;

module.exports = { REPORT_CSS, REPORT_STYLE_HEAD };
