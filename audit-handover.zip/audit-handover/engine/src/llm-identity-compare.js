// Qualitative comparison of a model answer against a dated brand-owned baseline.
// Phrase overlap only. It does not emit semantic_alignment, a confidence
// percentage, or a contradiction. A reviewer may attach those verdicts.

const FACTUAL = {
  dimension: "factual",
  verdict: "unknown",
  detail: "This check does not verify every generated factual claim.",
};

function hasPhrase(text, phrase) {
  const hay = String(text || "").toLowerCase();
  const needle = String(phrase || "").trim().toLowerCase();
  return Boolean(needle) && hay.includes(needle);
}

function dimension(name, phrases, text) {
  const list = (Array.isArray(phrases) ? phrases : []).map((p) => String(p).trim()).filter(Boolean);
  if (!list.length) {
    return {
      dimension: name,
      verdict: "unknown",
      detail: "No baseline phrases were supplied for this dimension.",
    };
  }
  const present = list.filter((phrase) => hasPhrase(text, phrase));
  const missing = list.filter((phrase) => !hasPhrase(text, phrase));
  if (name === "category" && present.length) {
    const omitted = missing.length ? ` Omitted: ${missing.join("; ")}.` : "";
    return {
      dimension: name,
      verdict: "exact_or_near_slogan",
      detail: `Baseline phrase appears in the answer: ${present.join("; ")}.${omitted}`,
    };
  }
  if (!present.length) {
    return {
      dimension: name,
      verdict: "omission",
      detail: `None of the supplied baseline phrases appear: ${missing.join("; ")}.`,
    };
  }
  const omitted = missing.length ? ` Omitted: ${missing.join("; ")}.` : "";
  return {
    dimension: name,
    verdict: "unknown",
    detail: `Supplied phrase appears in the answer: ${present.join("; ")}.${omitted} Paraphrase was not judged.`,
  };
}

function phraseCheck(baseline, text) {
  const source = baseline || {};
  return [
    dimension("category", source.categoryLabels, text),
    dimension("buyers", source.buyerPhrases, text),
    dimension("capabilities", source.capabilityPhrases, text),
    dimension("positioning", source.positioningPhrases, text),
    FACTUAL,
  ];
}

function compareSnapshot(baseline, text, reviewerDimensions) {
  const auto = phraseCheck(baseline, text);
  if (Array.isArray(reviewerDimensions) && reviewerDimensions.length) {
    return { method: "reviewer", dimensions: reviewerDimensions, phraseCheck: auto };
  }
  return { method: "phrase_check", dimensions: auto };
}

module.exports = { phraseCheck, compareSnapshot };
