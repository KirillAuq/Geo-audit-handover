const { callClaude, extractTextBlocks } = require("./claude-client");
const { extractHtmlFromAgent, safeHtml } = require("./report-html");

const CHUNK_SYSTEM = `You are the GEO audit report agent writing one section of a client-facing HTML report.

Rules:
- Output ONLY HTML for the requested section(s). No markdown fences, no preamble.
- Use <section class="card"> for each major block. Use <h2> for section headings (except the title block uses <h1> once).
- Writing: no em dashes or en dashes, max 2 sentences per paragraph, ~30 words per paragraph, no third-party tool names (say "search-intelligence data").
- Label fields use "Label. value" with a period, not a colon.
- Use tables and blockquotes where the section brief calls for them.`;

const REPORT_CHUNKS = [
  {
    id: "title-exec",
    label: "Title and Executive summary",
    maxTokens: 2800,
    brief: `Produce:
1. Title block with <h1> (brand name + "Brand-only positioning diagnostic"), plus 5 muted meta lines (domain, date, scope, etc.).
2. Executive summary: 2-3 short paragraphs, GEO score callout from geoScore, "Three findings that matter" bullets, "Top three moves" numbered list.`,
  },
  {
    id: "identity",
    label: "Identity in AIO",
    maxTokens: 3200,
    brief: `Produce Identity in AIO: "What the brand says" blockquote, "What AIO says" (1-3 blockquotes), category placement table, recurring descriptors, framing issues.`,
  },
  {
    id: "aio-performance",
    label: "AIO performance",
    maxTokens: 2800,
    brief: `Produce AIO performance: trigger/inclusion metrics table, standalone vs co-mentioned note, high-value AIO keywords table, citation footprint on own pages.`,
  },
  {
    id: "content-entity",
    label: "Content and entity coverage",
    maxTokens: 2600,
    brief: `Produce Content and entity coverage: topic clusters owned/partial table, invisible topics bullets, buyer-journey coverage table.`,
  },
  {
    id: "citations",
    label: "Citation sources",
    maxTokens: 2400,
    brief: `Produce Citation sources: top external domains AIO cites (table), off-site action list bullets.`,
  },
  {
    id: "peers",
    label: "AIO-revealed peers",
    maxTokens: 2400,
    brief: `Produce AIO-revealed peers: peers table with cluster and framing columns, short "note the framing" closer.`,
  },
  {
    id: "thirty-day",
    label: "30-day priority moves",
    maxTokens: 2600,
    brief: `Produce 30-day priority moves: exactly 5 moves as <h3> headings with 1-2 short paragraphs each.`,
  },
  {
    id: "roadmap-metrics",
    label: "90-day roadmap and Success metrics",
    maxTokens: 2800,
    brief: `Produce two subsections in one card or two cards:
1. 90-day roadmap: three sprints (days 1-30, 31-60, 61-90) as <h3> with bullets.
2. Success metrics: single table with baseline and what we measure columns.`,
  },
  {
    id: "methodology",
    label: "Methodology appendix",
    maxTokens: 2000,
    brief: `Produce Methodology appendix: data source, method, limitations, what this audit does not do. Keep concise.`,
  },
];

function truncateValue(value, maxChars) {
  if (value == null) return value;
  const text = typeof value === "string" ? value : JSON.stringify(value);
  if (text.length <= maxChars) return value;
  if (typeof value === "string") return `${value.slice(0, maxChars)}\n[truncated]`;
  return { truncated: true, preview: text.slice(0, maxChars) };
}

function buildReportContext(memory) {
  const site = memory.get("site");
  const ahrefs = memory.get("ahrefs");

  return {
    meta: memory.get("meta"),
    geoScore: memory.get("geoScore"),
    analysis: truncateValue(memory.get("analysis"), 14000),
    promptSet: truncateValue(memory.get("promptSet"), 8000),
    ahrefs: ahrefs?.summary ?? truncateValue(ahrefs, 12000),
    ahrefsErrors: ahrefs?.errors || [],
    site: site
      ? {
          domain: site.domain,
          fetchedAt: site.fetchedAt,
          pages: (site.pages || []).map((page) => ({
            path: page.path,
            url: page.url,
            excerpt: String(page.text || "").slice(0, 1500),
          })),
        }
      : null,
  };
}

function extractChunkHtml(text) {
  const html = extractHtmlFromAgent(text);
  if (html) return html;

  const sectionMatch = String(text || "").match(/<section[\s\S]*/i);
  if (sectionMatch) {
    const chunk = sectionMatch[0].trim();
    if (chunk.includes("</section>")) return chunk;
  }

  return null;
}

function placeholderSection(chunk, errorMessage) {
  return `<section class="card report-chunk-error" data-chunk="${safeHtml(chunk.id)}">
  <h2>${safeHtml(chunk.label)}</h2>
  <p class="muted">This section could not be generated. ${safeHtml(errorMessage)}</p>
</section>`;
}

async function generateChunkHtml({ chunk, contextJson, brand, domain }) {
  const userMessage = [
    `Brand: ${brand || domain}`,
    `Domain: ${domain}`,
    "",
    "Audit context (JSON). Use only facts present here:",
    contextJson,
    "",
    `Write HTML for: ${chunk.label}`,
    chunk.brief,
    "",
    "Return only HTML. Start with <section class=\"card\"> (or <header> for title block).",
  ].join("\n");

  const data = await callClaude({
    system: CHUNK_SYSTEM,
    messages: [{ role: "user", content: userMessage }],
    maxTokens: chunk.maxTokens,
  });

  const text = extractTextBlocks(data.content || []);
  const html = extractChunkHtml(text);
  if (!html) {
    throw new Error(`Chunk ${chunk.id} did not return valid HTML`);
  }
  return html;
}

async function runChunkedReport({ memory, directions: _directions, onProgress }) {
  const meta = memory.get("meta") || {};
  const domain = meta.domain || "unknown";
  const brand = memory.get("analysis")?.brand || meta.brandName || domain;
  const contextJson = JSON.stringify(buildReportContext(memory), null, 2);

  const sections = [];
  const log = { chunks: [], failed: [] };

  for (const chunk of REPORT_CHUNKS) {
    if (onProgress) onProgress(chunk.id);

    let html = null;
    let lastError = null;

    for (let attempt = 0; attempt < 2; attempt += 1) {
      try {
        html = await generateChunkHtml({ chunk, contextJson, brand, domain });
        break;
      } catch (error) {
        lastError = error;
        if (attempt === 0) {
          await new Promise((r) => setTimeout(r, 4000));
        }
      }
    }

    if (html) {
      sections.push(html);
      log.chunks.push({ id: chunk.id, ok: true, chars: html.length });
    } else {
      sections.push(placeholderSection(chunk, lastError?.message || "Unknown error"));
      log.failed.push({ id: chunk.id, error: lastError?.message });
    }

    await new Promise((r) => setTimeout(r, 1200));
  }

  const html = sections.join("\n\n");
  return { html, log, partial: log.failed.length > 0 };
}

module.exports = {
  REPORT_CHUNKS,
  buildReportContext,
  runChunkedReport,
  extractChunkHtml,
};
