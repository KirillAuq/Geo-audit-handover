const { REPORT_STYLE_HEAD } = require("./report-css");

function safeHtml(value) {
  return String(value)
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;")
    .replace(/'/g, "&#039;");
}

function sanitizeAgentHtml(html) {
  let out = String(html || "");
  out = out.replace(/<script[\s\S]*?<\/script>/gi, "");
  out = out.replace(/\son\w+\s*=\s*(".*?"|'.*?'|[^\s>]+)/gi, "");
  out = out.replace(/javascript:/gi, "");
  return out;
}

function extractHtmlFromAgent(text) {
  const raw = String(text || "").trim();
  const fenced = raw.match(/```html\s*([\s\S]*?)```/i);
  if (fenced) return fenced[1].trim();

  const docMatch = raw.match(/<!doctype[\s\S]*<\/html>/i) || raw.match(/<html[\s\S]*<\/html>/i);
  if (docMatch) return docMatch[0];

  const mainMatch = raw.match(/<main[\s\S]*<\/main>/i);
  if (mainMatch) return mainMatch[0];

  if (raw.includes("<section") || raw.includes("<h1")) return raw;
  return null;
}

function wrapReportPage({ bodyHtml, domain, brand, runId, warnings = [], errors = [] }) {
  const safeBody = sanitizeAgentHtml(bodyHtml);
  const warningBlock =
    warnings.length || errors.length
      ? `<section class="card report-warnings">
        <h2>Data warnings</h2>
        <ul>${[
          ...errors.map(
            (item) =>
              `<li><strong>${safeHtml(item.endpoint)}</strong>. ${safeHtml(item.message)}</li>`
          ),
          ...warnings.map((item) => `<li>${safeHtml(item)}</li>`),
        ].join("")}</ul>
      </section>`
      : "";

  return `<!doctype html>
<html lang="en">
  <head>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1" />
    <title>GEO Audit. ${safeHtml(brand || domain)}</title>
    ${REPORT_STYLE_HEAD}
  </head>
  <body class="report-page">
    <main class="container report-container">
      <a class="back-link" href="/app">← Run another audit</a>
      <p class="muted report-meta">Run ${safeHtml(runId)} · ${safeHtml(domain)}</p>
      <article class="report-body">${safeBody}</article>
      ${warningBlock}
    </main>
  </body>
</html>`;
}

function fallbackReportHtml({ domain, brand, errorMessage, memorySnapshot }) {
  return `<header class="report-header">
    <h1>GEO Audit. ${safeHtml(brand || domain)}</h1>
    <p class="muted">Report generation encountered an issue. Partial output is shown below.</p>
  </header>
  <section class="card">
    <h2>Status</h2>
    <p>${safeHtml(errorMessage)}</p>
  </section>
  <section class="card">
    <h2>Agent memory snapshot</h2>
    <pre class="memory-dump">${safeHtml(memorySnapshot)}</pre>
  </section>`;
}

module.exports = {
  wrapReportPage,
  extractHtmlFromAgent,
  sanitizeAgentHtml,
  fallbackReportHtml,
  safeHtml,
};
