// Independent identity check: "What does {brand} do?"
// DataForSEO AI Optimization LLM Responses Live.
// This module does not score Google AI Overviews and does not read the
// brand baseline into the prompt.
//
// Docs: https://docs.dataforseo.com/v3/ai_optimization/llm_responses/overview/
// Gemini Live does not document web_search_country_iso_code. Sending it
// returns 40501. ChatGPT Live does document that field. This check omits
// it for every provider so a ChatGPT example cannot be copied onto Gemini.

const PROVIDERS = [
  {
    id: "chatgpt",
    label: "ChatGPT",
    livePath: "/v3/ai_optimization/chat_gpt/llm_responses/live",
    modelsPath: "/v3/ai_optimization/chat_gpt/llm_responses/models",
    prefer: ["gpt-5", "gpt-4.1"],
  },
  {
    id: "gemini",
    label: "Gemini",
    livePath: "/v3/ai_optimization/gemini/llm_responses/live",
    modelsPath: "/v3/ai_optimization/gemini/llm_responses/models",
    prefer: ["gemini-2.5-flash", "gemini-2.5"],
  },
  {
    id: "claude",
    label: "Claude",
    livePath: "/v3/ai_optimization/claude/llm_responses/live",
    modelsPath: "/v3/ai_optimization/claude/llm_responses/models",
    prefer: ["claude-sonnet-4-5", "claude-sonnet"],
  },
  {
    id: "perplexity",
    label: "Perplexity",
    livePath: "/v3/ai_optimization/perplexity/llm_responses/live",
    modelsPath: "/v3/ai_optimization/perplexity/llm_responses/models",
    prefer: ["sonar-pro", "sonar"],
  },
];

const HOST = "https://api.dataforseo.com";
const SAMPLES_TARGET = 2;
const PROVIDERS_TARGET = 3;

function identityPrompt(brand) {
  const name = String(brand || "").trim();
  if (!name) throw new Error("brand is required");
  const prompt = `What does ${name} do?`;
  if (prompt.length > 500) throw new Error("user_prompt exceeds 500 characters");
  return prompt;
}

// Build the Live task body. Extra caller fields, including a country code
// copied from the ChatGPT docs, are ignored.
function identityRequestBody(providerId, opts = {}) {
  const prompt = String(opts.prompt || "");
  if (!prompt || prompt.length > 500) throw new Error("user_prompt must be 1 to 500 characters");
  if (!opts.modelName) throw new Error("model_name is required");
  const body = {
    user_prompt: prompt,
    model_name: String(opts.modelName),
    web_search: opts.webSearch !== false,
    max_output_tokens: Number(opts.maxOutputTokens) || 1024,
  };
  if (opts.tag) body.tag = String(opts.tag).slice(0, 200);
  delete body.web_search_country_iso_code;
  if (providerId === "gemini" && Object.prototype.hasOwnProperty.call(body, "web_search_country_iso_code")) {
    throw new Error("refusing gemini request with web_search_country_iso_code");
  }
  return body;
}

function credentials() {
  const login = process.env.GEO_AUDIT_DATAFORSEO_LOGIN || process.env.DATAFORSEO_LOGIN || "";
  const password = process.env.GEO_AUDIT_DATAFORSEO_PASSWORD || process.env.DATAFORSEO_PASSWORD || "";
  if (!login || !password) return null;
  return { login, password };
}

function authHeader() {
  const cred = credentials();
  if (!cred) return null;
  return "Basic " + Buffer.from(`${cred.login}:${cred.password}`, "utf8").toString("base64");
}

function publicError(err) {
  let message = String((err && err.message) || err || "request failed");
  message = message.replace(/Basic\s+[A-Za-z0-9+/=]+/gi, "Basic [redacted]");
  if (message.length > 300) message = message.slice(0, 300);
  return message;
}

function modelNamesFromResponse(json) {
  const names = [];
  for (const task of json?.tasks || []) {
    for (const row of task.result || []) {
      if (typeof row === "string" && row) names.push(row);
      else if (row && row.model_name) names.push(String(row.model_name));
    }
  }
  return names;
}

function pickModel(names, prefer) {
  const list = (names || []).filter(Boolean);
  for (const token of prefer || []) {
    const hit = list.find((name) => name.toLowerCase().includes(String(token).toLowerCase()));
    if (hit) return hit;
  }
  return list[0] || null;
}

function citationsFromResult(result) {
  const out = [];
  const push = (title, url) => {
    if (!url || typeof url !== "string") return;
    out.push({ title: title ? String(title) : "", url: String(url) });
  };
  for (const item of result?.items || []) {
    for (const section of item.sections || []) {
      for (const ann of section.annotations || []) {
        push(ann.title, ann.direct_url || ann.url);
      }
    }
  }
  for (const row of result?.search_results || []) {
    // Snippets are fetched page extracts, not the model answer. Drop them.
    push(row.title, row.url);
  }
  return out;
}

function textFromResult(result) {
  const parts = [];
  for (const item of result?.items || []) {
    for (const section of item.sections || []) {
      if (section && section.text) parts.push(String(section.text));
    }
  }
  return parts.join("\n\n").trim();
}

function snapshotFromLive(sample, requestedModel, payload) {
  const json = payload?.json || {};
  const task = json.tasks?.[0];
  const result = task?.result?.[0];
  const apiOk = json.status_code === 20000 && task?.status_code === 20000 && result;
  const text = apiOk ? textFromResult(result) : "";
  if (!apiOk || !text) {
    return {
      ok: false,
      sample,
      model: result?.model_name || null,
      requestedModel: requestedModel || null,
      datetimeUtc: result?.datetime || null,
      webSearch: result && typeof result.web_search === "boolean" ? result.web_search : null,
      costUsd: task?.cost ?? json.cost ?? null,
      text: null,
      citations: [],
      failure: {
        httpStatus: payload?.httpStatus || null,
        statusCode: task?.status_code || json.status_code || null,
        message: task?.status_message || json.status_message || (text ? "empty answer" : "no result"),
      },
    };
  }
  return {
    ok: true,
    sample,
    model: result.model_name || null,
    requestedModel: requestedModel || null,
    datetimeUtc: result.datetime || null,
    webSearch: result.web_search === true,
    costUsd: task?.cost ?? json.cost ?? null,
    text,
    citations: citationsFromResult(result),
    failure: null,
  };
}

function providerStatus(snapshots, samplesTarget) {
  const ok = snapshots.filter((s) => s.ok);
  if (!ok.length) return "not_tested";
  if (ok.length < samplesTarget) return "partial";
  return "ok";
}

function sectionStatus(providers) {
  const ok = providers.filter((p) => p.status === "ok" || p.status === "partial");
  if (!ok.length) return "not_tested";
  const full = providers.filter((p) => p.status === "ok").length;
  if (full >= PROVIDERS_TARGET) return "ok";
  return "partial";
}

function notTestedProvider(spec, message, statusCode) {
  return {
    id: spec.id,
    label: spec.label,
    status: "not_tested",
    failure: { statusCode: statusCode || null, message: message || "Not tested." },
    snapshots: [],
  };
}

async function collectIdentity({ brand, samples = SAMPLES_TARGET, post, baseline, tagPrefix } = {}) {
  const prompt = identityPrompt(brand);
  const providers = [];
  for (const spec of PROVIDERS) {
    try {
      const modelsPayload = await post(spec.modelsPath, { method: "GET" });
      const names = modelNamesFromResponse(modelsPayload.json);
      const requestedModel = pickModel(names, spec.prefer);
      if (!requestedModel) {
        providers.push(notTestedProvider(spec, "Models endpoint returned no model id."));
        continue;
      }
      const snapshots = [];
      for (let sample = 1; sample <= samples; sample++) {
        const body = identityRequestBody(spec.id, {
          prompt,
          modelName: requestedModel,
          tag: tagPrefix ? `${tagPrefix}-${spec.id}-s${sample}` : undefined,
          webSearchCountryIsoCode: "US",
        });
        if (Object.prototype.hasOwnProperty.call(body, "web_search_country_iso_code")) {
          throw new Error("country code leaked into " + spec.id);
        }
        const live = await post(spec.livePath, { method: "POST", body });
        snapshots.push(snapshotFromLive(sample, requestedModel, live));
      }
      providers.push({
        id: spec.id,
        label: spec.label,
        status: providerStatus(snapshots, samples),
        failure: snapshots.some((s) => s.ok) ? null : (snapshots[0]?.failure || { message: "Not tested." }),
        snapshots,
      });
    } catch (err) {
      providers.push(notTestedProvider(spec, publicError(err)));
    }
  }
  return {
    status: sectionStatus(providers),
    prompt,
    promptRule: "Exact neutral prompt. No system message. No brand baseline in the request.",
    transport: "LLM Responses API, Live method. Not a consumer chat screenshot.",
    providersTarget: PROVIDERS_TARGET,
    samplesTarget: samples,
    baseline: baseline || null,
    providers,
  };
}

async function defaultPost(pathname, { method = "GET", body } = {}) {
  const header = authHeader();
  if (!header) {
    const error = new Error("LLM identity credentials are not set");
    error.code = "NO_CREDENTIALS";
    throw error;
  }
  const res = await fetch(HOST + pathname, {
    method,
    headers: {
      Authorization: header,
      "Content-Type": "application/json",
    },
    body: method === "GET" ? undefined : JSON.stringify(body),
  });
  let json = {};
  try { json = await res.json(); } catch { json = {}; }
  return { httpStatus: res.status, json };
}

function assertNoSecretKeys(value) {
  if (!value || typeof value !== "object") return;
  for (const [key, child] of Object.entries(value)) {
    if (/password|authorization|api[_-]?key|secret|token/i.test(key)) {
      throw new Error("refusing to store " + key);
    }
    assertNoSecretKeys(child);
  }
}

module.exports = {
  PROVIDERS,
  SAMPLES_TARGET,
  PROVIDERS_TARGET,
  identityPrompt,
  identityRequestBody,
  credentials,
  modelNamesFromResponse,
  pickModel,
  snapshotFromLive,
  collectIdentity,
  defaultPost,
  assertNoSecretKeys,
  publicError,
  sectionStatus,
};
