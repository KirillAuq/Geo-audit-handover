function env(name, fallbackName = "") {
  return process.env[name] || (fallbackName ? process.env[fallbackName] : "");
}

function extractTextBlocks(content) {
  if (!Array.isArray(content)) return "";
  return content
    .filter((block) => block.type === "text")
    .map((block) => block.text)
    .join("\n");
}

function extractToolUses(content) {
  if (!Array.isArray(content)) return [];
  return content.filter((block) => block.type === "tool_use");
}

async function sleep(ms) {
  return new Promise((resolve) => setTimeout(resolve, ms));
}

function formatFetchError(error) {
  const cause = error.cause;
  const parts = [error.message];
  if (cause?.code) parts.push(String(cause.code));
  if (cause?.message && cause.message !== error.message) parts.push(cause.message);
  return parts.join(": ");
}

function retryDelayMs(response, attempt) {
  const retryAfter = response?.headers?.get?.("retry-after");
  if (retryAfter) {
    const seconds = Number(retryAfter);
    if (Number.isFinite(seconds) && seconds > 0) return seconds * 1000;
  }
  return 15000 * (attempt + 1);
}

async function callClaude({ system, messages, tools, maxTokens, model }) {
  const apiKey = env("GEO_AUDIT_CLAUDE_API_KEY", "ANTHROPIC_API_KEY");
  if (!apiKey) {
    throw new Error("Missing Claude API key. Set GEO_AUDIT_CLAUDE_API_KEY.");
  }

  const resolvedModel = model || env("GEO_AUDIT_CLAUDE_MODEL", "ANTHROPIC_MODEL") || "claude-sonnet-4-6";

  const body = {
    model: resolvedModel,
    max_tokens: maxTokens,
    messages,
  };
  if (system) body.system = system;
  if (tools?.length) body.tools = tools;

  let lastError;
  for (let attempt = 0; attempt < 4; attempt += 1) {
    let response;
    try {
      response = await fetch("https://api.anthropic.com/v1/messages", {
        method: "POST",
        headers: {
          "x-api-key": apiKey,
          "anthropic-version": "2023-06-01",
          "content-type": "application/json",
        },
        body: JSON.stringify(body),
      });
    } catch (error) {
      lastError = new Error(`Claude API network error: ${formatFetchError(error)}`);
      if (attempt === 3) throw lastError;
      await sleep(retryDelayMs(null, attempt));
      continue;
    }

    const text = await response.text();
    let data;
    try {
      data = JSON.parse(text);
    } catch {
      lastError = new Error(
        `Claude API invalid JSON (${response.status}): ${text.slice(0, 300)}`
      );
      if (attempt === 3) throw lastError;
      await sleep(retryDelayMs(response, attempt));
      continue;
    }

    if (response.ok) return data;

    const retryable = response.status === 429 || response.status >= 500;
    lastError = new Error(
      `Claude API failed (${response.status}): ${JSON.stringify(data).slice(0, 500)}`
    );
    if (!retryable || attempt === 3) throw lastError;
    await sleep(retryDelayMs(response, attempt));
  }

  throw lastError;
}

async function runClaudeAgent({
  system,
  userMessage,
  tools = [],
  toolHandlers = {},
  maxTurns = 14,
  maxTokens = 8000,
  model,
}) {
  const messages = [{ role: "user", content: userMessage }];
  let lastText = "";

  for (let turn = 0; turn < maxTurns; turn += 1) {
    const data = await callClaude({ system, messages, tools, maxTokens, model });
    const assistantContent = data.content || [];
    lastText = extractTextBlocks(assistantContent);
    messages.push({ role: "assistant", content: assistantContent });

    const toolUses = extractToolUses(assistantContent);
    if (!toolUses.length) {
      return { text: lastText, messages, stopReason: data.stop_reason, turns: turn + 1 };
    }

    const toolResults = [];
    for (const toolUse of toolUses) {
      const handler = toolHandlers[toolUse.name];
      let result;
      try {
        if (!handler) {
          result = { error: `Unknown tool: ${toolUse.name}` };
        } else {
          result = await handler(toolUse.input || {});
        }
      } catch (error) {
        result = { error: error.message };
      }
      toolResults.push({
        type: "tool_result",
        tool_use_id: toolUse.id,
        content: JSON.stringify(result),
      });
    }

    messages.push({ role: "user", content: toolResults });
    await sleep(500);
  }

  return { text: lastText, messages, stopReason: "max_turns", turns: maxTurns };
}

module.exports = {
  runClaudeAgent,
  callClaude,
  extractTextBlocks,
};
