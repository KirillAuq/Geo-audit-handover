// Progress hooks for measure(): a start line, a queue status line while reads
// are outstanding, one line per finished query, and a save of the partial
// results after each query.
//
// Without these a run prints nothing until the end, which looks identical to a
// hang, and a stopped run loses every read it already paid for.
//
// Partial saves carry `aio.partial: true` and `meta.phase: "collecting"`, so
// verify.js reports them as incomplete instead of scoring them.

function progressHooks(memory, domain) {
  const started = Date.now();
  const elapsed = () => `${Math.round((Date.now() - started) / 1000)}s`;
  let lastStatus = "";
  let lastStatusAt = 0;
  let runMode = "";

  return {
    async onStart({ total, samples, timeoutSec, mode, priority, sampleStaggerSec, stragglerSec }) {
      runMode = mode;
      memory.merge("meta", { phase: "collecting", queryCount: total, samples, aioMode: mode });
      await memory.save();
      const how = mode === "standard"
        ? `Standard queue, priority ${priority === 2 ? "high" : priority} | sample rounds ${sampleStaggerSec}s apart | Live fallback after ${stragglerSec}s`
        : "Live, one read at a time";
      console.log(`[${domain}] runId ${memory.runId} | ${total} queries x ${samples} samples | ${how} | request timeout ${timeoutSec}s`);
    },
    // Standard mode only: printed when the counts change, at most every 15s.
    async onStatus({ elapsedSec, roundsPosted, samples, readsBack, readsTotal, queued, viaLive }) {
      const line = `rounds posted ${roundsPosted}/${samples} | reads back ${readsBack}/${readsTotal} | queued ${queued} | via Live ${viaLive}`;
      if (line === lastStatus || Date.now() - lastStatusAt < 15000) return;
      lastStatus = line;
      lastStatusAt = Date.now();
      console.log(`[${domain}] ${elapsedSec}s queue: ${line}`);
    },
    async onQuery({ index, total, result, partial }) {
      memory.set("aio", partial);
      await memory.save();
      const width = String(total).length;
      const status = result.error ? `ERROR ${result.error}` : result.bucket;
      const live = runMode === "standard" && result.viaLive ? ` (${result.viaLive} via Live)` : "";
      console.log(`[${domain}] [${String(index).padStart(width)}/${total}] ${elapsed()} ${result.query} -> ${status}${live}`);
    },
  };
}

module.exports = { progressHooks };
