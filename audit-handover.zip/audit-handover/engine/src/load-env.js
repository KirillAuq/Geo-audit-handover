// Minimal .env loader, so the audit pipeline runs on a stock Node install with
// no `npm install` and no node_modules. Drop-in for dotenv's config({path}).
//
// Deliberately small: KEY=VALUE per line, `#` comments, optional `export`
// prefix, optional matching single or double quotes, and \n unescaped inside
// double quotes. Existing environment variables always win, which matches
// dotenv and is what lets an exported key override the file.
const fs = require("fs");

function parse(src) {
  const out = {};
  for (let line of String(src).split(/\r?\n/)) {
    line = line.trim();
    if (!line || line.startsWith("#")) continue;
    if (line.startsWith("export ")) line = line.slice(7).trim();
    const eq = line.indexOf("=");
    if (eq < 1) continue;
    const key = line.slice(0, eq).trim();
    if (!/^[A-Za-z_][A-Za-z0-9_]*$/.test(key)) continue;
    let val = line.slice(eq + 1).trim();
    const q = val[0];
    if ((q === '"' || q === "'") && val[val.length - 1] === q && val.length > 1) {
      val = val.slice(1, -1);
      if (q === '"') val = val.replace(/\\n/g, "\n").replace(/\\r/g, "\r");
    } else {
      const hash = val.indexOf(" #");
      if (hash > -1) val = val.slice(0, hash).trim();
    }
    out[key] = val;
  }
  return out;
}

function config({ path: file } = {}) {
  if (!file || !fs.existsSync(file)) return { parsed: {} };
  let parsed;
  try {
    parsed = parse(fs.readFileSync(file, "utf8"));
  } catch {
    return { parsed: {} };
  }
  for (const [k, v] of Object.entries(parsed)) {
    if (process.env[k] === undefined) process.env[k] = v;
  }
  return { parsed };
}

module.exports = { config, parse };
