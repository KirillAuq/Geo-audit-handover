// Google AI Overview reader (the measurement layer).
//
// Query-anchored: submit a positioning query, read the AIO from a Google SERP via
// DataForSEO, and bucket the brand's presence deterministically. It works whether
// or not the brand ranks, and it returns the full citation list (the brand and
// every competitor).
//
// Two delivery modes, same data, same parsing, same bucketing:
//
//   standard (default)  DataForSEO Standard queue at high priority. All queries
//                       for a sample round go in one task_post, results are
//                       collected via tasks_ready + task_get. ~2-3 min per audit,
//                       $0.0024 per read. Unreadable reads and stragglers fall
//                       back to a Live read, so no query waits on the queue for
//                       long.
//   live                One Live request per read, one at a time. ~15 min per
//                       audit, up to $0.004 per read. Kept as the fallback path
//                       and for comparison runs (GEO_AUDIT_AIO_MODE=live).
//
// Auth: set GEO_AUDIT_DATAFORSEO_LOGIN and GEO_AUDIT_DATAFORSEO_PASSWORD in .env.

const API = "https://api.dataforseo.com/v3/serp/google/organic";
const LIVE_URL = `${API}/live/advanced`;
const POST_URL = `${API}/task_post`;
const READY_URL = `${API}/tasks_ready`;
const GET_URL = (id) => `${API}/task_get/advanced/${id}`;
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
const round4 = (n) => Math.round(n * 10000) / 10000;

// Config is read at call time so a run (or a test) can set it via env.
const num = (name, dflt) => {
  const v = Number(process.env[name]);
  return Number.isFinite(v) && process.env[name] !== "" && process.env[name] !== undefined ? v : dflt;
};
function config() {
  return {
    mode: String(process.env.GEO_AUDIT_AIO_MODE || "standard").toLowerCase(),
    // DataForSEO recommends a 120s client timeout for SERP requests.
    timeoutSec: num("GEO_AUDIT_REQUEST_TIMEOUT_SEC", 120),
    // Standard queue only. Priority 2 = high (~1 min turnaround), 1 = normal (~5 min).
    priority: num("GEO_AUDIT_PRIORITY", 2),
    // Seconds between posting sample round 1, 2, ... Samples posted at the same
    // instant disagree far less than Live samples, so they are spaced out.
    sampleStaggerSec: num("GEO_AUDIT_SAMPLE_STAGGER_SEC", 60),
    // A queued read not back after this long is re-read Live instead.
    stragglerSec: num("GEO_AUDIT_STRAGGLER_SEC", 90),
    // tasks_ready is limited to 20 calls/min account-wide; 10s = 6/min per audit.
    pollSec: num("GEO_AUDIT_POLL_SEC", 10),
  };
}

function authHeader() {
  const login = process.env.GEO_AUDIT_DATAFORSEO_LOGIN;
  const password = process.env.GEO_AUDIT_DATAFORSEO_PASSWORD;
  if (!login || !password) {
    throw new Error(
      "Missing DataForSEO creds. Set GEO_AUDIT_DATAFORSEO_LOGIN and GEO_AUDIT_DATAFORSEO_PASSWORD."
    );
  }
  return "Basic " + Buffer.from(`${login}:${password}`).toString("base64");
}

function registrable(domain) {
  return String(domain || "").replace(/^www\./i, "").toLowerCase();
}

// One DataForSEO call with a hard time limit. Throws on HTTP or API-level errors.
async function dfs(url, { method = "GET", body } = {}) {
  const { timeoutSec } = config();
  let res, json;
  try {
    res = await fetch(url, {
      method,
      headers: { Authorization: authHeader(), "Content-Type": "application/json" },
      body: body ? JSON.stringify(body) : undefined,
      // Covers the response body too, so a stalled stream is also cut off.
      signal: AbortSignal.timeout(timeoutSec * 1000),
    });
    json = await res.json();
  } catch (e) {
    if (e && (e.name === "TimeoutError" || e.name === "AbortError")) {
      throw new Error(`DataForSEO request timed out after ${timeoutSec}s`);
    }
    throw e;
  }
  if (!res.ok || (json.status_code && json.status_code >= 40000)) {
    throw new Error(`DataForSEO HTTP ${res.status} / status ${json.status_code}: ${json.status_message || ""}`);
  }
  return json;
}

// ---- discovery: positioning query construction -----------------------------
// Built from the brand's own positioning, never from a keyword index by traffic.
function buildPositioningQueries(identity, { maxQueries = 40 } = {}) {
  const brand = String(identity.brand || "").trim();
  const brandLc = brand.toLowerCase();
  // Themes are category terms ONLY (never product or brand names). Product
  // names like "Haystack" or "Elemez" would generate trivially-true branded
  // queries ("best haystack"), so they are excluded from the query set; they
  // live in identity.products only for differentiator text and alias matching.
  const rawThemes = [
    ...new Set((identity.categories || []).map((t) => String(t || "").trim().toLowerCase()).filter(Boolean)),
  ];
  // Belt-and-suspenders: also drop any category that contains the brand name.
  const themes = rawThemes.filter((t) => t && !t.includes(brandLc) && !brandLc.includes(t));
  const competitors = (identity.competitors || []).map((c) => String(c).trim()).filter(Boolean);

  // Non-branded, decision-stage modifiers applied to each category theme.
  const MODS = ["best {t}", "{t} vendors", "{t} solutions", "{t} software", "{t} platform", "top {t} providers", "{t} comparison"];
  const positioning = [];
  for (const t of themes) for (const tpl of MODS) positioning.push(tpl.replace("{t}", t));

  // Lean comparison layer — only to surface AIO-revealed peers; kept small.
  const comparison = [
    ...(brand ? [`alternatives to ${brand}`] : []),
    ...competitors.slice(0, 3).map((c) => `${brand} vs ${c}`),
  ];

  const queries = [...new Set([...positioning, ...comparison])].slice(0, maxQueries);
  return { branded: [], positioning, comparison, queries };
}

// ---- parsing ---------------------------------------------------------------
// Walk the AIO element (top-level + nested items) and collect every cited domain.
function collectRefDomains(node, out) {
  if (!node || typeof node !== "object") return;
  for (const key of ["references", "links"]) {
    if (Array.isArray(node[key])) {
      for (const r of node[key]) if (r && r.domain) out.add(registrable(r.domain));
    }
  }
  if (Array.isArray(node.items)) for (const child of node.items) collectRefDomains(child, out);
}

function parseAio(aio) {
  if (!aio) return { triggered: false, pending: false, text: "", citationDomains: [] };
  // Async render: the element is present but its content/citations were not
  // returned. Triggered, but unreadable until re-fetched.
  const pending = aio.asynchronous_ai_overview === true && !aio.references && !aio.items;
  const domains = new Set();
  collectRefDomains(aio, domains);
  const text = aio.markdown || (Array.isArray(aio.items) ? aio.items.map((i) => i.text || "").join(" ") : "");
  return { triggered: true, pending, text, citationDomains: [...domains] };
}

function parseItems(items) {
  items = items || [];
  const aio = items.find((it) => it.type === "ai_overview") || null;
  const organicDomains = items.filter((it) => it.type === "organic" && it.domain).map((it) => registrable(it.domain));
  return { ...parseAio(aio), organicDomains };
}

const task = (keyword, extra = {}) => ({
  keyword, location_name: "United States", language_code: "en", device: "desktop", depth: 10,
  // Return the asynchronously-rendered AI Overview instead of a pending stub.
  load_async_ai_overview: true,
  ...extra,
});

// ---- Live: one read --------------------------------------------------------
async function readAioOnce(keyword, cost) {
  const json = await dfs(LIVE_URL, { method: "POST", body: [task(keyword)] });
  if (cost) { cost.liveUsd += json.cost || 0; cost.liveReads++; }
  return parseItems(json.tasks?.[0]?.result?.[0]?.items);
}

// One Live sample, re-requested while the AIO is still an unreadable async stub.
async function readLiveSample(keyword, { retryPending = 3, pendingDelayMs = 6000, cost } = {}) {
  let read = await readAioOnce(keyword, cost);
  for (let tries = 0; read.pending && tries < retryPending; tries++) {
    await sleep(pendingDelayMs);
    read = await readAioOnce(keyword, cost);
  }
  return read;
}

// Combine a query's samples: triggered if any fired, citations unioned.
function combine(reads) {
  return {
    triggered: reads.some((r) => r.triggered),
    pending: reads.some((r) => r.pending) && reads.every((r) => !r.triggered || r.pending),
    citationDomains: [...new Set(reads.flatMap((r) => r.citationDomains))],
    organicDomains: [...new Set(reads.flatMap((r) => r.organicDomains || []))],
    text: reads.map((r) => r.text).sort((a, b) => b.length - a.length)[0] || "",
    triggerRate: reads.filter((r) => r.triggered).length / reads.length,
    samples: reads.length,
  };
}

// Sample a query several times over Live (AIO triggering is volatile).
async function readAio(keyword, opts = {}) {
  const { samples = 2 } = opts;
  const reads = [];
  for (let s = 0; s < samples; s++) reads.push(await readLiveSample(keyword, opts));
  return { keyword, ...combine(reads) };
}

// ---- deterministic bucketing (three signals, no judgment) ------------------
// owned                -> brand's domain is cited as a source in the AIO
// mentioned_not_cited  -> brand named in the AIO text, but its domain is not a source
// invisible            -> AIO fired, brand neither named nor cited
// aio_pending          -> AIO present but rendered async and could not be read
// no_aio               -> AIO did not fire for this query (not "invisible")
function bucket(read, targetDomain, aliases = []) {
  const target = registrable(targetDomain);
  if (!read.triggered) return "no_aio";
  if (read.citationDomains.map(registrable).includes(target)) return "owned";
  const hay = (read.text || "").toLowerCase();
  const named = aliases.some((a) => a && hay.includes(String(a).toLowerCase()));
  if (named) return "mentioned_not_cited";
  if (read.pending) return "aio_pending";
  return "invisible";
}

function toResult(query, layer, read, domain, aliases, extra = {}) {
  return {
    query,
    layer,
    bucket: bucket(read, domain, aliases),
    triggered: read.triggered,
    triggerRate: read.triggerRate,
    pending: read.pending,
    citedDomains: read.citationDomains,
    ...extra,
  };
}

const errorResult = (query, layer, message, extra = {}) =>
  // A DataForSEO/network error on one query must not kill the whole domain.
  ({ query, layer, bucket: "no_aio", triggered: false, triggerRate: 0, pending: false, citedDomains: [], error: message, ...extra });

// ---- orchestrator ----------------------------------------------------------
async function measure(domain, identity, opts = {}) {
  const cfg = config();
  const mode = opts.mode || cfg.mode;
  if (!["standard", "live"].includes(mode)) throw new Error(`Unknown GEO_AUDIT_AIO_MODE "${mode}" (use standard or live)`);
  const aliases = [identity.brand, ...(identity.products || [])].filter(Boolean);
  const { queries, comparison } = buildPositioningQueries(identity, opts);
  const layerOf = (q) => (comparison.includes(q) ? "comparison" : "positioning");
  const samples = opts.samples ?? 2;
  const cost = { standardUsd: 0, liveUsd: 0, standardReads: 0, liveReads: 0 };
  const started = Date.now();

  if (opts.onStart) {
    await opts.onStart({ total: queries.length, samples, timeoutSec: cfg.timeoutSec, mode, priority: cfg.priority, sampleStaggerSec: cfg.sampleStaggerSec, stragglerSec: cfg.stragglerSec });
  }
  const ctx = { domain, aliases, queries, layerOf, samples, cost, cfg, opts };
  const results = mode === "live" ? await measureLive(ctx) : await measureStandard(ctx);

  return {
    ...summarize(domain, queries, results),
    mode,
    durationSec: Math.round((Date.now() - started) / 1000),
    cost: {
      ...cost,
      standardUsd: round4(cost.standardUsd),
      liveUsd: round4(cost.liveUsd),
      totalUsd: round4(cost.standardUsd + cost.liveUsd),
    },
  };
}

// Progress hook: callers print a line and save partial results, so a run is
// visibly moving and a stopped run keeps what it already paid for.
async function emit(ctx, done, result) {
  if (!ctx.opts.onQuery) return;
  const ordered = done.filter(Boolean);
  await ctx.opts.onQuery({
    index: ordered.length,
    total: ctx.queries.length,
    result,
    partial: { ...summarize(ctx.domain, ctx.queries, ordered), partial: true },
  });
}

async function measureLive(ctx) {
  const { queries, layerOf, domain, aliases, samples, cost } = ctx;
  const done = [];
  for (const [i, q] of queries.entries()) {
    try {
      const read = await readAio(q, { ...ctx.opts, samples, cost });
      done[i] = toResult(q, layerOf(q), read, domain, aliases, { samplesRead: read.samples, viaLive: read.samples });
    } catch (e) {
      done[i] = errorResult(q, layerOf(q), String((e && e.message) || e));
    }
    await emit(ctx, done, done[i]);
  }
  return done;
}

async function measureStandard(ctx) {
  const { queries, layerOf, domain, aliases, samples, cost, cfg, opts } = ctx;
  const t0 = Date.now();
  const elapsed = () => Math.round((Date.now() - t0) / 1000);
  const slots = queries.map(() => new Array(samples).fill(null)); // {read, via} | {error}
  const queued = new Map(); // taskId -> {i, s, at}
  let fallback = []; // [{i, s, reason}]
  const done = [];
  let round = 0;
  let lastSweep = Date.now();
  const status = () => opts.onStatus && opts.onStatus({
    elapsedSec: elapsed(), roundsPosted: round, samples,
    readsBack: slots.flat().filter(Boolean).length, readsTotal: queries.length * samples,
    queued: queued.size, viaLive: slots.flat().filter((x) => x && x.via === "live").length,
  });

  async function postRound(s) {
    // One task_post holds up to 100 tasks; chunk for safety on larger sets.
    for (let k = 0; k < queries.length; k += 100) {
      const idx = queries.map((_, i) => i).slice(k, k + 100);
      try {
        const json = await dfs(POST_URL, { method: "POST", body: idx.map((i) => task(queries[i], { priority: cfg.priority, tag: `${i}|${s}` })) });
        cost.standardUsd += json.cost || 0;
        for (const t of json.tasks || []) {
          const [i] = String(t.data?.tag || "").split("|").map(Number);
          if (t.status_code === 20100) { queued.set(t.id, { i, s, at: Date.now() }); cost.standardReads++; }
          else fallback.push({ i, s, reason: `not queued: ${t.status_code} ${t.status_message}` });
        }
      } catch (e) {
        for (const i of idx) fallback.push({ i, s, reason: `task_post failed: ${e.message}` });
      }
    }
  }

  async function collect(ids) {
    for (let k = 0; k < ids.length; k += 8) {
      await Promise.all(ids.slice(k, k + 8).map(async (id) => {
        const q = queued.get(id);
        if (!q) return;
        let t;
        try {
          t = (await dfs(GET_URL(id))).tasks?.[0];
        } catch (e) {
          return; // transient; the next poll or the straggler rule picks it up
        }
        if (!t || [40601, 40602].includes(t.status_code)) return; // handed / in queue
        queued.delete(id);
        if (t.status_code !== 20000) return fallback.push({ i: q.i, s: q.s, reason: `queue task failed: ${t.status_code} ${t.status_message}` });
        const read = parseItems(t.result?.[0]?.items);
        if (read.pending) return fallback.push({ i: q.i, s: q.s, reason: "unreadable AI Overview from queue" });
        slots[q.i][q.s] = { read, via: "standard" };
      }));
    }
  }

  while (done.filter(Boolean).length < queries.length) {
    // Post sample rounds on schedule: round 0 now, round s after s x stagger.
    while (round < samples && Date.now() - t0 >= round * cfg.sampleStaggerSec * 1000) await postRound(round++);

    // Collect whatever the queue says is ready.
    if (queued.size) {
      let ready = [];
      try {
        const json = await dfs(READY_URL);
        ready = (json.tasks?.[0]?.result || []).map((x) => x.id).filter((id) => queued.has(id));
      } catch (e) { /* rate-limited or transient; the sweep below covers it */ }
      // Every 30s also ask directly for tasks queued over 30s, in case tasks_ready missed one.
      if (Date.now() - lastSweep > 30000) {
        lastSweep = Date.now();
        for (const [id, q] of queued) if (Date.now() - q.at > 30000 && !ready.includes(id)) ready.push(id);
      }
      await collect(ready);
    }

    // Stragglers: still queued past the limit are re-read Live.
    for (const [id, q] of queued) {
      if (Date.now() - q.at > cfg.stragglerSec * 1000) {
        queued.delete(id);
        fallback.push({ i: q.i, s: q.s, reason: `still queued after ${cfg.stragglerSec}s` });
      }
    }

    // Live fallback, two at a time.
    const batch = fallback;
    fallback = [];
    for (let k = 0; k < batch.length; k += 2) {
      await Promise.all(batch.slice(k, k + 2).map(async ({ i, s, reason }) => {
        try {
          slots[i][s] = { read: await readLiveSample(queries[i], { ...opts, cost }), via: "live", reason };
        } catch (e) {
          slots[i][s] = { error: `${reason}; Live fallback failed: ${e.message}` };
        }
      }));
    }

    // Emit every query whose samples are all in.
    for (const [i, q] of queries.entries()) {
      if (done[i] || slots[i].some((x) => x === null)) continue;
      const reads = slots[i].filter((x) => x.read).map((x) => x.read);
      const errors = [...new Set(slots[i].filter((x) => x.error).map((x) => x.error))];
      const viaLive = slots[i].filter((x) => x.via === "live").length;
      done[i] = reads.length
        ? toResult(q, layerOf(q), combine(reads), domain, aliases, { samplesRead: reads.length, viaLive, ...(errors.length ? { sampleErrors: errors } : {}) })
        : errorResult(q, layerOf(q), errors.join("; "), { samplesRead: 0, viaLive });
      await emit(ctx, done, done[i]);
    }

    await status();
    if (done.filter(Boolean).length < queries.length) await sleep(cfg.pollSec * 1000);
  }
  return done;
}

function summarize(domain, queries, results) {
  const counts = results.reduce((m, r) => ((m[r.bucket] = (m[r.bucket] || 0) + 1), m), {});
  // AIO-revealed peers: domains cited on queries where the brand is not owned.
  const peers = {};
  for (const r of results) {
    if (r.bucket === "owned") continue;
    for (const d of r.citedDomains) if (registrable(d) !== registrable(domain)) peers[d] = (peers[d] || 0) + 1;
  }
  const topPeers = Object.entries(peers)
    .sort((a, b) => b[1] - a[1])
    .slice(0, 15)
    .map(([d, n]) => ({ domain: d, citations: n }));

  const triggered = results.filter((r) => r.triggered).length;
  return {
    domain,
    queryCount: queries.length,
    aioTriggerRatePct: queries.length ? Math.round((triggered / queries.length) * 100) : 0,
    counts,
    topPeers,
    results,
  };
}

module.exports = { buildPositioningQueries, readAio, parseAio, bucket, measure, registrable, config };
