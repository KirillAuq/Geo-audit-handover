const express = require("express");
const path = require("path");

const { runAuditAgent } = require("./audit-agent");
const { wrapReportPage, safeHtml } = require("./report-html");

const PUBLIC_DIR = path.join(__dirname, "..", "public");

function normalizeDomain(input) {
  const raw = String(input || "").trim();
  if (!raw) return "";

  try {
    const url = raw.includes("://") ? new URL(raw) : new URL(`https://${raw}`);
    return url.hostname.replace(/^www\./i, "").toLowerCase();
  } catch {
    return "";
  }
}

async function handleAuditPost(req, res) {
  const domain = normalizeDomain(req.body.domain);
  if (!domain) {
    res.status(400).send("Invalid domain. Please go back and enter a valid URL or domain.");
    return;
  }

  try {
    const result = await runAuditAgent(domain);
    res.send(
      wrapReportPage({
        bodyHtml: result.reportHtml,
        domain,
        brand: result.brandName,
        runId: result.runId,
        warnings: result.ahrefsWarnings,
        errors: result.ahrefsErrors,
      })
    );
  } catch (error) {
    console.error("Audit failed:", error);
    const detail =
      error.cause?.message && error.cause.message !== error.message
        ? `${error.message} (${error.cause.message})`
        : error.message;
    res.status(500).send(`Audit failed: ${safeHtml(detail)}`);
  }
}

function createApp() {
  const app = express();

  app.use(express.urlencoded({ extended: false }));
  app.use(express.json());

  if (!process.env.VERCEL) {
    app.use(express.static(PUBLIC_DIR));
    app.get("/app", (req, res) => {
      res.sendFile(path.join(PUBLIC_DIR, "app", "index.html"));
    });
  }

  app.get("/api", (req, res) => {
    res.status(200).json({ ok: true, service: "geo-audit" });
  });

  // Vercel rewrites POST /audit → /api/audit; register all paths.
  app.post("/audit", handleAuditPost);
  app.post("/api/audit", handleAuditPost);
  app.post("/api", handleAuditPost);

  app.use((error, req, res, next) => {
    console.error("Unhandled error:", error);
    if (res.headersSent) {
      next(error);
      return;
    }
    res.status(500).send(`Audit failed: ${safeHtml(error.message)}`);
  });

  return app;
}

module.exports = { createApp, normalizeDomain, PUBLIC_DIR };
