// Insight facts: the grounding for the "What it found" and "Pitch" chat
// write-up that closes every audit. Pure functions over run memory and the
// canonical object. No network, no LLM. normalize_aio.js stores the result as
// canonical.analysis.insightFacts; scripts/insights.js prints it as a fact sheet.

const decode = (s) => String(s || "").replace(/&amp;/g, "&").replace(/&#x27;|&#39;/g, "'").replace(/&quot;/g, '"').replace(/\s+/g, " ").trim();

function tally(list) {
  const n = {};
  for (const d of list) n[d] = (n[d] || 0) + 1;
  return Object.entries(n).sort((a, b) => b[1] - a[1]).map(([domain, count]) => ({ domain, count }));
}

// Theme verdict. Same rule as normalize_aio.js's coverage rollup, so the chat
// never contradicts the report's coverage table.
function verdictOf(cited, named, absent) {
  if (cited >= Math.max(named, absent) && cited > 0) return "strong";
  if (absent >= Math.max(cited, named) && absent > 0) return "missing";
  if (named > 0) return "named_only";
  return "strong";
}

function buildFacts(memory, canon) {
  const aio = memory.aio || {};
  const identity = memory.identity || {};
  const domain = String(memory.meta?.domain || aio.domain || "").toLowerCase().replace(/^www\./, "");
  const brand = canon?.geoScore?.brand || memory.meta?.brand || identity.brand || domain;
  const brandLc = brand.toLowerCase();
  const isOwn = (x) => x === domain || x.endsWith("." + domain);
  const results = aio.results || [];
  const counts = aio.counts || {};

  // Same grouping as normalize_aio.js: longest identity category contained in the query.
  const cats = [...(identity.categories || []), ...(identity.products || [])]
    .map((s) => String(s).toLowerCase()).filter(Boolean).sort((a, b) => b.length - a.length);
  const themeOf = (r) => {
    if (r.layer === "branded") return null;
    const q = String(r.query).toLowerCase();
    for (const c of cats) if (q.includes(c)) return c;
    return r.layer === "comparison" ? null : "(other)";
  };
  const groups = {};
  for (const r of results) {
    const t = themeOf(r);
    if (t && t !== brandLc) (groups[t] = groups[t] || []).push(r);
  }
  const themes = Object.entries(groups).map(([theme, rs]) => {
    const by = (b) => rs.filter((r) => r.bucket === b);
    const cited = by("owned"), named = by("mentioned_not_cited"), absent = by("invisible");
    return {
      theme,
      verdict: verdictOf(cited.length, named.length, absent.length),
      queries: rs.length,
      cited: cited.length,
      citedOn: cited.map((r) => r.query),
      citedInstead: tally([...named, ...absent].flatMap((r) => (r.citedDomains || []).filter((x) => !isOwn(x)))).slice(0, 5),
    };
  });

  const queryFacts = (layer) => results.filter((r) => r.layer === layer).map((r) => {
    const pos = (r.citedDomains || []).findIndex(isOwn);
    return { query: r.query, bucket: r.bucket, ownSourcePosition: pos >= 0 ? pos + 1 : null, topSources: (r.citedDomains || []).slice(0, 4) };
  });

  const selfDescription = decode(canon?.analysis?.identityGap?.brandSelfDescription).split(" | ")[0].slice(0, 110);
  const pages = memory.site?.pages || [];
  const home = pages.find((x) => /^https?:\/\/[^/]+\/?$/.test(x.url || "")) || pages[0];

  return {
    brand,
    domain,
    score: canon?.geoScore?.overallScore ?? null,
    band: canon?.geoScore?.band || "",
    triggerRatePct: aio.aioTriggerRatePct ?? null,
    queryCount: results.length,
    counts: { cited: counts.owned || 0, namedNotCited: counts.mentioned_not_cited || 0, absent: counts.invisible || 0, noAio: counts.no_aio || 0 },
    homepageTitle: selfDescription,
    homepageUrl: home?.url || "",
    categories: identity.categories || [],
    competitors: identity.competitors || [],
    themes,
    brandedQueries: queryFacts("branded"),
    comparisonQueries: queryFacts("comparison"),
    topDomainsWhereAbsent: tally(results.filter((r) => r.bucket === "invisible").flatMap((r) => (r.citedDomains || []).filter((x) => !isOwn(x)))).slice(0, 8),
    wikipediaCitedOn: results.filter((r) => (r.citedDomains || []).some((x) => /wikipedia\.org$/.test(x))).map((r) => r.query),
  };
}

const VERDICT = { strong: "STRONG", missing: "MISSING", named_only: "NAMED ONLY" };
const BUCKET = { owned: "CITED", mentioned_not_cited: "NAMED, NOT CITED", invisible: "ABSENT", no_aio: "NO AI ANSWER", aio_pending: "PENDING" };
const list = (xs) => xs.map((x) => `${x.domain} (${x.count})`).join(", ");

function formatFacts(f, runId) {
  const out = [];
  const p = (s = "") => out.push(s);
  p(`=== ${f.brand} (${f.domain})${runId ? `  run ${runId}` : ""}`);
  p(`Score ${f.score ?? "?"}/100, band ${f.band || "?"}. AI Overview shown on ${f.triggerRatePct}% of ${f.queryCount} queries. ${f.brand} cited in ${f.counts.cited}, named but not cited in ${f.counts.namedNotCited}, absent from ${f.counts.absent}, no AI answer on ${f.counts.noAio}.`);
  if (f.homepageTitle) p(`Homepage title: "${f.homepageTitle}"${f.homepageUrl ? ` (${f.homepageUrl})` : ""}`);
  p(`Identity categories: ${f.categories.join(", ") || "(none)"}. Competitors seeded: ${f.competitors.join(", ") || "(none)"}.`);

  p("\nTHEMES (positioning queries, grouped by identity category; verdict matches the report's coverage table)");
  for (const t of f.themes) {
    p(`- ${t.theme}: ${VERDICT[t.verdict]}, cited on ${t.cited} of ${t.queries}.${t.citedInstead.length ? ` Cited instead where ${f.brand} is missing: ${list(t.citedInstead)}.` : ""}`);
    p(`    cited on: ${t.citedOn.map((q) => `"${q}"`).join(", ") || "none"}`);
  }
  for (const [label, qs] of [["BRANDED QUERIES", f.brandedQueries], ["COMPARISON QUERIES", f.comparisonQueries]]) {
    if (!qs.length) continue;
    p(`\n${label}`);
    for (const q of qs) p(`- "${q.query}": ${BUCKET[q.bucket] || q.bucket}${q.ownSourcePosition ? ` (own domain is source #${q.ownSourcePosition})` : ""}. Top sources: ${q.topSources.join(", ") || "none"}.`);
  }
  p("\nTOP DOMAINS CITED ON QUERIES WHERE THE BRAND IS ABSENT");
  p(list(f.topDomainsWhereAbsent) || "none");
  if (f.wikipediaCitedOn.length) p(`Wikipedia cited on: ${f.wikipediaCitedOn.map((q) => `"${q}"`).join(", ")}`);
  return out.join("\n");
}

module.exports = { buildFacts, formatFacts };
