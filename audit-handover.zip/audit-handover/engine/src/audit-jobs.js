const fs = require("fs/promises");
const path = require("path");
const { AgentMemory, DATA_ROOT } = require("./agent-memory");
const { runAuditAgent } = require("./audit-agent");

function statusPath(runId) {
  return path.join(DATA_ROOT, runId, "status.json");
}

async function writeJobStatus(runId, patch) {
  const file = statusPath(runId);
  let current = {};
  try {
    current = JSON.parse(await fs.readFile(file, "utf8"));
  } catch {
    // new file
  }
  const next = {
    ...current,
    ...patch,
    runId,
    updatedAt: new Date().toISOString(),
  };
  await fs.mkdir(path.dirname(file), { recursive: true });
  await fs.writeFile(file, JSON.stringify(next, null, 2), "utf8");
  return next;
}

async function readJobStatus(runId) {
  try {
    return JSON.parse(await fs.readFile(statusPath(runId), "utf8"));
  } catch {
    return null;
  }
}

async function startAuditJob(domain) {
  const memory = await AgentMemory.create(domain);
  const runId = memory.runId;

  await writeJobStatus(runId, {
    domain,
    phase: "queued",
    detail: "Starting audit",
    complete: false,
    error: null,
    startedAt: new Date().toISOString(),
  });

  setImmediate(() => {
    runAuditJob(runId, domain, memory).catch((error) => {
      console.error(`Audit job ${runId} failed:`, error);
    });
  });

  return runId;
}

async function runAuditJob(runId, domain, memory) {
  const onPhase = async (phase, detail) => {
    await writeJobStatus(runId, { phase, detail: detail || phase, complete: false, error: null });
  };

  try {
    const result = await runAuditAgent(domain, {
      memory,
      onPhase,
      onReportChunk: (chunkId) => onPhase("report", `Writing section: ${chunkId}`),
    });

    await writeJobStatus(runId, {
      phase: "complete",
      detail: "Report ready",
      complete: true,
      error: null,
      domain: result.domain,
      brandName: result.brandName,
      partial: Boolean(result.reportPartial),
    });
  } catch (error) {
    await writeJobStatus(runId, {
      phase: "error",
      detail: error.message,
      complete: true,
      error: error.message,
    });
  }
}

module.exports = {
  startAuditJob,
  readJobStatus,
  writeJobStatus,
  statusPath,
};
