function stripHtml(html) {
  return String(html || "")
    .replace(/<script[\s\S]*?<\/script>/gi, " ")
    .replace(/<style[\s\S]*?<\/style>/gi, " ")
    .replace(/<[^>]+>/g, " ")
    .replace(/\s+/g, " ")
    .trim();
}

function truncate(text, max = 8000) {
  const value = String(text || "");
  if (value.length <= max) return value;
  return `${value.slice(0, max)}\n[truncated]`;
}

async function fetchPageText(url, timeoutMs = 15000) {
  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), timeoutMs);
  try {
    const response = await fetch(url, {
      signal: controller.signal,
      headers: {
        "User-Agent": "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36",
        Accept: "text/html,*/*",
        "Accept-Language": "en-US,en;q=0.9",
      },
      redirect: "follow",
    });
    const html = await response.text();
    if (!response.ok) {
      return { url, ok: false, status: response.status, text: "" };
    }
    return { url, ok: true, status: response.status, text: truncate(stripHtml(html)) };
  } catch (error) {
    return { url, ok: false, error: error.message, text: "" };
  } finally {
    clearTimeout(timer);
  }
}

async function extractSiteIdentity(domain) {
  const paths = ["/", "/about", "/products", "/pricing"];
  const pages = [];

  for (const pathname of paths) {
    const url = `https://${domain}${pathname === "/" ? "" : pathname}`;
    const page = await fetchPageText(url);
    if (page.ok && page.text.length > 200) {
      pages.push({ path: pathname, url: page.url, text: page.text });
    }
    if (pages.length >= 3) break;
  }

  if (!pages.length) {
    const fallback = await fetchPageText(`https://www.${domain}`);
    if (fallback.ok && fallback.text) {
      pages.push({ path: "/", url: fallback.url, text: fallback.text });
    }
  }

  return {
    domain,
    fetchedAt: new Date().toISOString(),
    pages,
  };
}

module.exports = {
  extractSiteIdentity,
  fetchPageText,
  stripHtml,
};
