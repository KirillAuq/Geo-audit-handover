const path = require("path");

require("./load-env").config({ path: path.join(__dirname, "..", ".env") });

const { createApp } = require("./app");

const app = createApp();
const PORT = process.env.PORT || 3000;

const server = app.listen(PORT, () => {
  console.log(`GEO audit running on http://localhost:${PORT}`);
  console.log(`  Landing: http://localhost:${PORT}/`);
  console.log(`  App:     http://localhost:${PORT}/app`);
});

server.on("error", (error) => {
  if (error.code === "EADDRINUSE") {
    console.error(
      `Port ${PORT} is already in use. Stop the other process (Ctrl+C) or run:\n  lsof -ti:${PORT} | xargs kill -9`
    );
    process.exit(1);
  }
  throw error;
});
