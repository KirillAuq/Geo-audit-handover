// Description-match percent for "What does {Brand} do?"
//
// This is a count of reviewed homepage claims, not a confidence score and not
// a similarity model. Phrase overlap must not call this. A claim counts only
// after a person records matched, missed, or contradiction with a written reason.
//
// Equal provider weight: each provider's matched/evaluated ratio counts once,
// then those ratios are averaged. A provider with more samples does not
// outweigh a provider with fewer. Failed and unreviewed providers are left
// out. They are not scored as zero.

const COUNTED = new Set(["matched", "missed", "contradiction"]);

// A decision with no written reason is not a review. String presence is not a reason.
function reviewReason(row) {
  return String(row?.reason || row?.note || "").trim();
}

function isReviewed(row, ids) {
  return Boolean(row) && ids.has(row.id) && COUNTED.has(row.decision) && reviewReason(row).length >= 20;
}

function claimList(record) {
  return (Array.isArray(record?.claims) ? record.claims : [])
    .filter((claim) => claim && claim.id && claim.text);
}

function reviewedRows(snapshot, ids) {
  return (Array.isArray(snapshot?.claims) ? snapshot.claims : []).filter((row) => isReviewed(row, ids));
}

function descriptionMatch(record) {
  const claims = claimList(record);
  const ids = new Set(claims.map((claim) => claim.id));
  const providers = Array.isArray(record?.providers) ? record.providers : [];
  const scored = [];
  const excluded = [];

  for (const provider of providers) {
    const id = provider.id || provider.label || "provider";
    if (provider.status === "not_tested") {
      excluded.push({ id, reason: "not_tested" });
      continue;
    }
    const snaps = (provider.snapshots || []).filter((snap) => snap && snap.ok !== false);
    let matched = 0;
    let evaluated = 0;
    let answers = 0;
    for (const snap of snaps) {
      const rows = reviewedRows(snap, ids);
      if (!rows.length) continue;
      answers += 1;
      evaluated += rows.length;
      matched += rows.filter((row) => row.decision === "matched").length;
    }
    if (!answers) {
      excluded.push({ id, reason: snaps.length ? "unreviewed" : "no_answer" });
      continue;
    }
    scored.push({ id, matched, evaluated, answers, rate: matched / evaluated });
  }

  const answers = scored.reduce((sum, provider) => sum + provider.answers, 0);
  const pooledMatched = scored.reduce((sum, provider) => sum + provider.matched, 0);
  const pooledEvaluated = scored.reduce((sum, provider) => sum + provider.evaluated, 0);
  if (!claims.length || !scored.length) {
    return {
      status: "not_scored",
      percent: null,
      method: "equal_provider_weight",
      models: 0,
      answers: 0,
      providers: [],
      excluded,
      pooledMatched: 0,
      pooledEvaluated: 0,
    };
  }
  const mean = scored.reduce((sum, provider) => sum + provider.rate, 0) / scored.length;
  return {
    status: scored.length >= 3 ? "scored" : "partial",
    percent: Math.round(mean * 100),
    method: "equal_provider_weight",
    models: scored.length,
    answers,
    providers: scored,
    excluded,
    pooledMatched,
    pooledEvaluated,
  };
}

function perClaimRates(record) {
  const claims = claimList(record);
  const ids = new Set(claims.map((claim) => claim.id));
  const providers = (record?.providers || []).filter((provider) => provider.status !== "not_tested");
  return claims.map((claim) => {
    const rates = [];
    for (const provider of providers) {
      let matched = 0;
      let evaluated = 0;
      for (const snap of provider.snapshots || []) {
        if (!snap || snap.ok === false) continue;
        const row = (snap.claims || []).find((item) => item.id === claim.id && isReviewed(item, ids));
        if (!row) continue;
        evaluated += 1;
        if (row.decision === "matched") matched += 1;
      }
      if (evaluated) rates.push(matched / evaluated);
    }
    const rate = rates.length ? rates.reduce((sum, value) => sum + value, 0) / rates.length : null;
    return { id: claim.id, text: claim.text, rate, providers: rates.length };
  });
}

function omissionGaps(record) {
  const claims = claimList(record);
  const providers = (record?.providers || []).filter((provider) => provider.status !== "not_tested");
  return claims.filter((claim) => {
    const rates = [];
    for (const provider of providers) {
      let hit = 0;
      let seen = 0;
      for (const snap of provider.snapshots || []) {
        if (!snap || snap.ok === false) continue;
        const row = (snap.claims || []).find((item) => item.id === claim.id && isReviewed(item, new Set([claim.id])) && (item.decision === "matched" || item.decision === "missed"));
        if (!row) continue;
        seen += 1;
        if (row.decision === "matched") hit += 1;
      }
      if (seen) rates.push(hit / seen);
    }
    if (!rates.length) return false;
    const rate = rates.reduce((sum, value) => sum + value, 0) / rates.length;
    return rate < 0.5;
  }).map((claim) => claim.text);
}

function contradictionNotes(record) {
  const claims = new Map(claimList(record).map((claim) => [claim.id, claim.text]));
  const notes = [];
  for (const provider of record?.providers || []) {
    for (const snap of provider.snapshots || []) {
      for (const row of snap?.claims || []) {
        if (!isReviewed(row, claims.size ? new Set(claims.keys()) : new Set([row.id]))) continue;
        if (row.decision !== "contradiction") continue;
        const label = claims.get(row.id) || row.id;
        const why = reviewReason(row);
        notes.push(`${label}: ${why}`);
      }
    }
  }
  return notes;
}

function publicSummary(record) {
  const match = descriptionMatch(record);
  const says = String(record?.homepage?.says || "").trim();
  const failed = (match.excluded || []).filter((item) => item.reason === "not_tested" || item.reason === "no_answer").length;
  const gaps = omissionGaps(record);
  const contradictions = contradictionNotes(record);
  return { match, says, failed, gaps, contradictions };
}

module.exports = {
  descriptionMatch,
  perClaimRates,
  omissionGaps,
  contradictionNotes,
  publicSummary,
};
