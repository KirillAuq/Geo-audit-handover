const fs = require("fs/promises");
const path = require("path");
const crypto = require("crypto");

// Vercel serverless only allows writes under /tmp.
const DATA_ROOT = process.env.VERCEL
  ? path.join("/tmp", "geo-audit-runs")
  : path.join(__dirname, "..", ".data", "runs");

function runDir(runId) {
  return path.join(DATA_ROOT, runId);
}

function memoryPath(runId) {
  return path.join(runDir(runId), "memory.json");
}

class AgentMemory {
  constructor(runId, data = {}) {
    this.runId = runId;
    this.data = data;
    this.dirty = false;
  }

  static async create(domain) {
    const runId = crypto.randomBytes(8).toString("hex");
    await fs.mkdir(runDir(runId), { recursive: true });
    const memory = new AgentMemory(runId, {
      meta: {
        domain,
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString(),
      },
    });
    await memory.save();
    return memory;
  }

  static async load(runId) {
    const raw = await fs.readFile(memoryPath(runId), "utf8");
    return new AgentMemory(runId, JSON.parse(raw));
  }

  keys() {
    return Object.keys(this.data).sort();
  }

  get(key) {
    return this.data[key];
  }

  set(key, value) {
    this.data[key] = value;
    this.touch();
    this.dirty = true;
    return value;
  }

  merge(key, partial) {
    const current =
      this.data[key] && typeof this.data[key] === "object" && !Array.isArray(this.data[key])
        ? this.data[key]
        : {};
    this.data[key] = { ...current, ...partial };
    this.touch();
    this.dirty = true;
    return this.data[key];
  }

  append(key, item) {
    const list = Array.isArray(this.data[key]) ? this.data[key] : [];
    list.push(item);
    this.data[key] = list;
    this.touch();
    this.dirty = true;
    return list;
  }

  touch() {
    if (!this.data.meta) this.data.meta = {};
    this.data.meta.updatedAt = new Date().toISOString();
  }

  snapshot(maxChars = 60000) {
    const copy = JSON.parse(JSON.stringify(this.data));
    let text = JSON.stringify(copy, null, 2);
    if (text.length > maxChars) {
      text = `${text.slice(0, maxChars)}\n\n[memory snapshot truncated]`;
    }
    return text;
  }

  async save() {
    await fs.mkdir(runDir(this.runId), { recursive: true });
    await fs.writeFile(memoryPath(this.runId), JSON.stringify(this.data, null, 2), "utf8");
    this.dirty = false;
  }

  prepareValueForTool(key, value) {
    if (value == null) return null;

    if (key === "site" && value.pages) {
      return {
        ...value,
        pages: value.pages.map((page) => ({
          ...page,
          text: String(page.text || "").slice(0, 4500),
        })),
      };
    }

    if (key === "ahrefs" && value.summary) {
      return value;
    }

    if (typeof value === "string" && value.length > 14000) {
      return `${value.slice(0, 14000)}\n[truncated for tool response]`;
    }

    const serialized = JSON.stringify(value);
    if (serialized.length > 18000) {
      return {
        truncated: true,
        note: "Value too large for one tool response. Read smaller keys or nested fields.",
        preview: serialized.slice(0, 16000),
      };
    }

    return value;
  }

  createToolHandlers() {
    const memory = this;
    return {
      memory_keys: async () => ({ keys: memory.keys() }),
      memory_read: async ({ key }) => ({
        key,
        value: memory.prepareValueForTool(key, memory.get(key)) ?? null,
      }),
      memory_write: async ({ key, value_json, value }) => {
        const parsed = value_json != null ? JSON.parse(value_json) : value;
        memory.set(key, parsed);
        await memory.save();
        return { ok: true, key };
      },
      memory_merge: async ({ key, value_json, value }) => {
        const parsed = value_json != null ? JSON.parse(value_json) : value;
        memory.merge(key, parsed);
        await memory.save();
        return { ok: true, key };
      },
      memory_append: async ({ key, item_json, item }) => {
        const parsed = item_json != null ? JSON.parse(item_json) : item;
        const list = memory.append(key, parsed);
        await memory.save();
        return { ok: true, key, length: list.length };
      },
    };
  }
}

const MEMORY_TOOLS = [
  {
    name: "memory_keys",
    description: "List all keys currently stored in this audit run memory.",
    input_schema: { type: "object", properties: {}, additionalProperties: false },
  },
  {
    name: "memory_read",
    description: "Read a value from audit run memory by key.",
    input_schema: {
      type: "object",
      properties: {
        key: { type: "string", description: "Memory key, e.g. site, ahrefs, analysis" },
      },
      required: ["key"],
      additionalProperties: false,
    },
  },
  {
    name: "memory_write",
    description:
      "Replace a memory key with a JSON value. Pass value_json as a JSON string (object, array, or scalar).",
    input_schema: {
      type: "object",
      properties: {
        key: { type: "string" },
        value_json: { type: "string", description: "Stringified JSON value" },
      },
      required: ["key", "value_json"],
      additionalProperties: false,
    },
  },
  {
    name: "memory_merge",
    description: "Shallow-merge fields into an existing memory object key. Pass value_json as a JSON object string.",
    input_schema: {
      type: "object",
      properties: {
        key: { type: "string" },
        value_json: { type: "string", description: "Stringified JSON object to merge" },
      },
      required: ["key", "value_json"],
      additionalProperties: false,
    },
  },
  {
    name: "memory_append",
    description: "Append one item to a memory array key. Pass item_json as a JSON string.",
    input_schema: {
      type: "object",
      properties: {
        key: { type: "string" },
        item_json: { type: "string", description: "Stringified JSON item to append" },
      },
      required: ["key", "item_json"],
      additionalProperties: false,
    },
  },
];

module.exports = {
  AgentMemory,
  MEMORY_TOOLS,
  DATA_ROOT,
};
