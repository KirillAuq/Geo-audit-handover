const { AgentMemory, MEMORY_TOOLS } = require("./agent-memory");
const { runClaudeAgent } = require("./claude-client");
const { collectAhrefsData, inferBrandName } = require("./ahrefs-mcp");
const { extractSiteIdentity } = require("./site-fetch");
const { readAuditReferences, buildDirectionsBlock } = require("./audit-references");
const { wrapReportPage, fallbackReportHtml } = require("./report-html");
const { runChunkedReport } = require("./report-chunks");

function summarizeAhrefsForMemory(results) {
  const keywords = results.organicKeywords?.keywords || [];
  const withAioTrigger = keywords.filter((row) =>
    String(row.serp_features || "").includes("ai_overview")
  );
  const inAio = keywords.filter((row) => row.best_position_kind === "ai_overview");
  const highValueGap = withAioTrigger
    .filter((row) => row.best_position_kind !== "ai_overview")
    .sort((a, b) => (b.volume || 0) - (a.volume || 0))
    .slice(0, 12);

  return {
    brandName: results.brandName,
    domain: results.domain,
    date: results.date,
    dataSource: results.brandRadarDataSource,
    mentionsTotal: results.mentionsOverview?.metrics?.[0]?.total ?? null,
    citedPages: (results.citedPages?.pages || []).slice(0, 20),
    citedDomains: (results.citedDomains?.domains || []).slice(0, 20),
    aiResponses: (results.aiResponses?.ai_responses || []).slice(0, 5).map((row) => ({
      question: row.question,
      volume: row.volume,
      response: String(row.response || "").slice(0, 1200),
    })),
    organicKeywordsSample: keywords.slice(0, 25),
    aioMetrics: {
      trackedKeywords: keywords.length,
      aioTriggerCount: withAioTrigger.length,
      inAioInclusionCount: inAio.length,
      highValueAioKeywordsNotInOverview: highValueGap,
    },
    topPages: (results.topPages?.pages || []).slice(0, 15),
  };
}

const ANALYSIS_SYSTEM = `You are the GEO audit analysis agent for a brand-only Google AI Overviews diagnostic.

You have memory tools to read and write structured findings for this run. The server has already stored site extraction and Ahrefs summaries in memory.

Your job in this phase:
1. Read memory keys "site", "ahrefs", and "meta".
2. Follow the audit spec and runbook directions provided in the user message.
3. Build a prompt set (20-40 prompts, three layers) and store it under key "promptSet".
4. Perform analysis: identity gap, AIO performance metrics, content coverage, citation landscape, AIO-revealed peers, GEO score (0-100 with component breakdown and band label).
5. Store structured output under key "analysis" and score under "geoScore".
6. Append brief working notes to key "notes" as needed (use memory_append with item_json).

For memory_write, memory_merge, and memory_append, pass data as value_json / item_json (stringified JSON).

Writing rules for any client-facing strings you store: no em dashes, no en dashes, max 2 sentences per paragraph, ~30 words max, no third-party tool names (say "search-intelligence data" instead).

Do not generate the final HTML report in this phase.`;

async function runAnalysisPhase({ memory, directions }) {
  const toolHandlers = memory.createToolHandlers();
  const keys = memory.keys();

  const userMessage = [
    "Audit directions are in the system prompt. Read memory keys `site` and `ahrefs` for collected data.",
    "",
    `Memory keys available: ${keys.join(", ")}. Use memory_read; do not request full dumps in chat.`,
    "",
    "Complete the analysis phase. Use memory_write / memory_merge / memory_append tools (value_json / item_json strings).",
    "When finished, reply with a one-sentence confirmation listing keys you wrote.",
  ].join("\n");

  const result = await runClaudeAgent({
    system: `${ANALYSIS_SYSTEM}\n\n${directions}`,
    userMessage,
    tools: MEMORY_TOOLS,
    toolHandlers,
    maxTurns: 12,
    maxTokens: 6000,
  });

  memory.merge("agentLog", { analysisPhase: { turns: result.turns, preview: result.text.slice(0, 500) } });
  await memory.save();
  return result;
}

async function runReportPhase({ memory, directions, onReportChunk }) {
  const result = await runChunkedReport({
    memory,
    directions,
    onProgress: onReportChunk || ((chunkId) => console.log(`Report chunk: ${chunkId}`)),
  });

  if (result.html) {
    memory.set("reportHtml", result.html);
  }
  memory.merge("agentLog", {
    reportPhase: {
      mode: "chunked",
      chunks: result.log.chunks,
      failed: result.log.failed,
      partial: result.partial,
    },
  });
  await memory.save();
  return { html: result.html, raw: "", partial: result.partial };
}

function isRateLimitError(message) {
  return /429|rate_limit/i.test(String(message || ""));
}

async function setPhase(memory, onPhase, phase, detail) {
  const patch = { phase };
  if (phase === "complete") patch.completedAt = new Date().toISOString();
  memory.merge("meta", patch);
  await memory.save();
  if (onPhase) await onPhase(phase, detail);
}

async function runAuditAgent(domain, options = {}) {
  const { memory: existingMemory, onPhase, onReportChunk } = options;
  const references = await readAuditReferences();
  const directions = buildDirectionsBlock(references);
  const memory = existingMemory || (await AgentMemory.create(domain));
  const brandName = inferBrandName(domain);

  await setPhase(memory, onPhase, "collect", "Fetching site and search-intelligence data");

  const [site, ahrefsBundle] = await Promise.all([
    extractSiteIdentity(domain),
    collectAhrefsData(domain),
  ]);

  memory.set("site", site);
  memory.set("ahrefs", {
    summary: summarizeAhrefsForMemory(ahrefsBundle.results),
    errors: ahrefsBundle.errors,
    warnings: ahrefsBundle.warnings,
  });
  await setPhase(memory, onPhase, "analyze", "Running analysis agent");

  let analysisRateLimited = false;
  try {
    await runAnalysisPhase({ memory, directions });
  } catch (error) {
    analysisRateLimited = isRateLimitError(error.message);
    memory.append("notes", {
      phase: "analysis",
      error: error.message,
      at: new Date().toISOString(),
    });
    await memory.save();
    console.warn("Analysis phase failed, continuing to report:", error.message);
  }

  await setPhase(memory, onPhase, "report", "Generating report sections");

  const cooldownMs = analysisRateLimited ? 65000 : 8000;
  await new Promise((r) => setTimeout(r, cooldownMs));

  let reportResult = { html: null, raw: "", partial: false };
  try {
    reportResult = await runReportPhase({
      memory,
      directions,
      onReportChunk: onReportChunk || ((chunkId) => console.log(`Report chunk: ${chunkId}`)),
    });
  } catch (error) {
    memory.append("notes", {
      phase: "report",
      error: error.message,
      at: new Date().toISOString(),
    });
    await memory.save();
    console.warn("Report phase failed, using fallback HTML:", error.message);
  }

  const reportHtml =
    reportResult.html ||
    memory.get("reportHtml") ||
    fallbackReportHtml({
      domain,
      brand: memory.get("analysis")?.brand || brandName,
      errorMessage:
        memory.get("notes")?.find?.((n) => n.phase === "report")?.error ||
        "The report agent did not return valid HTML.",
      memorySnapshot: memory.snapshot(40000),
    });

  memory.set("reportHtml", reportHtml);
  await setPhase(memory, onPhase, "complete", "Done");

  return {
    runId: memory.runId,
    domain,
    brandName: memory.get("analysis")?.brand || brandName,
    reportHtml,
    reportPartial: reportResult.partial,
    memory,
    ahrefsErrors: ahrefsBundle.errors,
    ahrefsWarnings: ahrefsBundle.warnings,
  };
}

module.exports = {
  runAuditAgent,
  summarizeAhrefsForMemory,
};
