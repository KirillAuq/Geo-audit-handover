function env(name, fallbackName = "") {
  return process.env[name] || (fallbackName ? process.env[fallbackName] : "");
}

function inferBrandName(domain) {
  const stem = domain.split(".")[0] || domain;
  return stem.charAt(0).toUpperCase() + stem.slice(1);
}

function parseToolResult(mcpResponse) {
  if (mcpResponse.error) {
    throw new Error(mcpResponse.error.message || JSON.stringify(mcpResponse.error));
  }

  const block = mcpResponse.result?.content?.[0];
  if (!block) return mcpResponse.result || null;

  if (block.type === "text" && block.text) {
    try {
      return JSON.parse(block.text);
    } catch {
      return { raw: block.text };
    }
  }

  return mcpResponse.result;
}

// Keyword-triggered AIO citations; `google_ai_overviews` alone often returns 0 for
// brands that still have real cited-page visibility (e.g. microblink.com).
const BRAND_RADAR_DATA_SOURCE = "google_ai_overviews_keywords";

function aioBaseArgs(brandName) {
  return {
    data_source: [BRAND_RADAR_DATA_SOURCE],
    country: ["us"],
    competitors: [{ names: [brandName] }],
  };
}

function brandRadarMentionTotal(mentionsOverview) {
  const metrics = mentionsOverview?.metrics;
  if (!Array.isArray(metrics) || !metrics.length) return null;
  const total = metrics[0]?.total;
  return typeof total === "number" ? total : null;
}

function brandRadarWarnings(results) {
  const warnings = [];
  const mentions = brandRadarMentionTotal(results.mentionsOverview);
  const citedPages = results.citedPages?.pages?.length || 0;
  const citedDomains = results.citedDomains?.domains?.length || 0;
  const hasOrganic = (results.organicKeywords?.keywords?.length || 0) > 0;

  if (mentions === 0 && citedPages === 0 && citedDomains === 0 && hasOrganic) {
    warnings.push(
      "Brand Radar returned no AIO keyword citations for this brand name. Ahrefs may not index this entity under the inferred name — verify the brand string in Ahrefs Brand Radar."
    );
  }

  return warnings;
}

function recentMonthDate() {
  const d = new Date();
  d.setDate(1);
  return d.toISOString().slice(0, 10);
}

class AhrefsMcpClient {
  constructor() {
    this.url = env("GEO_AUDIT_AHREFS_MCP_URL") || "https://api.ahrefs.com/mcp/mcp";
    this.apiKey =
      env("GEO_AUDIT_AHREFS_MCP_KEY", "GEO_AUDIT_AHREFS_API_KEY") || env("AHREFS_API_KEY");
    this.requestId = 0;
    this.initialized = false;
  }

  async call(method, params) {
    if (!this.apiKey) {
      throw new Error("Missing Ahrefs MCP key. Set GEO_AUDIT_AHREFS_MCP_KEY.");
    }

    const response = await fetch(this.url, {
      method: "POST",
      headers: {
        Authorization: `Bearer ${this.apiKey}`,
        "Content-Type": "application/json",
        Accept: "application/json, text/event-stream",
      },
      body: JSON.stringify({
        jsonrpc: "2.0",
        id: ++this.requestId,
        method,
        params,
      }),
    });

    const text = await response.text();
    let data;
    try {
      data = JSON.parse(text);
    } catch {
      throw new Error(`Ahrefs MCP invalid JSON (${response.status}): ${text.slice(0, 200)}`);
    }

    if (!response.ok) {
      throw new Error(`Ahrefs MCP HTTP ${response.status}: ${text.slice(0, 300)}`);
    }

    return data;
  }

  async ensureInitialized() {
    if (this.initialized) return;
    await this.call("initialize", {
      protocolVersion: "2024-11-05",
      capabilities: {},
      clientInfo: { name: "geo-audit-workflow", version: "1.0.0" },
    });
    this.initialized = true;
  }

  async callTool(name, args) {
    await this.ensureInitialized();
    const response = await this.call("tools/call", { name, arguments: args });
    if (response.result?.isError) {
      const message = response.result.content?.[0]?.text || "Unknown Ahrefs tool error";
      throw new Error(`${name}: ${message}`);
    }
    return parseToolResult(response);
  }
}

async function collectAhrefsData(domain) {
  const client = new AhrefsMcpClient();
  const brandName = inferBrandName(domain);
  const date = recentMonthDate();
  const aio = aioBaseArgs(brandName);

  const calls = [
    {
      key: "organicKeywords",
      name: "site-explorer-organic-keywords",
      args: {
        target: domain,
        mode: "subdomains",
        country: "us",
        date,
        select:
          "keyword,sum_traffic,volume,best_position,best_position_kind,serp_features,is_branded",
        limit: 40,
      },
    },
    {
      key: "topPages",
      name: "site-explorer-top-pages",
      args: {
        target: domain,
        mode: "subdomains",
        country: "us",
        date,
        select: "url,sum_traffic,top_keyword,top_keyword_volume,keywords",
        limit: 25,
      },
    },
    {
      key: "mentionsOverview",
      name: "brand-radar-mentions-overview-entities",
      args: {
        ...aio,
        select: ["brand", "total", "target_and_competitors_brands"],
      },
    },
    {
      key: "citedDomains",
      name: "brand-radar-cited-domains-entities",
      args: {
        ...aio,
        select: ["domain", "mentions", "pages"],
        limit: 15,
      },
    },
    {
      key: "citedPages",
      name: "brand-radar-cited-pages-entities",
      args: {
        ...aio,
        select: ["url", "mentions", "responses"],
        limit: 20,
      },
    },
    {
      key: "aiResponses",
      name: "brand-radar-ai-responses-entities",
      args: {
        ...aio,
        select: ["question", "response", "links", "volume"],
        order_by: "volume",
        limit: 6,
      },
    },
  ];

  const results = {
    brandName,
    domain,
    date,
    brandRadarDataSource: BRAND_RADAR_DATA_SOURCE,
  };
  const errors = [];

  for (const call of calls) {
    try {
      results[call.key] = await client.callTool(call.name, call.args);
    } catch (error) {
      errors.push({ endpoint: call.name, message: error.message });
    }
  }

  const warnings = brandRadarWarnings(results);

  return { results, errors, warnings };
}

module.exports = {
  AhrefsMcpClient,
  collectAhrefsData,
  inferBrandName,
  BRAND_RADAR_DATA_SOURCE,
  brandRadarMentionTotal,
};
