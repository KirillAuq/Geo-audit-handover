const fs = require("fs/promises");
const path = require("path");

function truncate(text, max = 18000) {
  const value = String(text || "");
  if (value.length <= max) return value;
  return `${value.slice(0, max)}\n\n[truncated]`;
}

function extractRunbook(skillText) {
  const marker = "# GEO Audit Runbook";
  const idx = skillText.indexOf(marker);
  if (idx >= 0) return skillText.slice(idx);
  const alt = "## Appendix A.";
  const altIdx = skillText.indexOf(alt);
  if (altIdx >= 0) return skillText.slice(0, altIdx);
  return skillText;
}

async function readAuditReferences() {
  const base = path.join(__dirname, "..");
  const [spec, skill, methodology, ahrefsNotes] = await Promise.all([
    fs.readFile(path.join(base, "GEO-Audit-Spec-v1-Brand-Only.md"), "utf8"),
    fs.readFile(path.join(base, "Audit-SKILL.md"), "utf8"),
    fs.readFile(path.join(base, "references", "methodology.md"), "utf8"),
    fs.readFile(path.join(base, "references", "ahrefs-api.md"), "utf8"),
  ]);

  return {
    spec: truncate(spec, 5500),
    runbook: truncate(extractRunbook(skill), 4500),
    methodology: truncate(methodology, 2800),
    ahrefsNotes: truncate(ahrefsNotes, 2000),
  };
}

function buildDirectionsBlock(references) {
  return [
    "=== GEO Audit Spec (v1 Brand-Only) ===",
    references.spec,
    "",
    "=== Operational Runbook (from Audit-SKILL) ===",
    references.runbook,
    "",
    "=== Methodology ===",
    references.methodology,
    "",
    "=== Data Source Notes (measurement: DataForSEO AIO; discovery: brand positioning) ===",
    references.ahrefsNotes,
  ].join("\n");
}

module.exports = {
  readAuditReferences,
  buildDirectionsBlock,
};
