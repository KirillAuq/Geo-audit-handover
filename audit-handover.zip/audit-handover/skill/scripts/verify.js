#!/usr/bin/env node
// Verify GEO-audit runs: flag stragglers (rate-limited / failed) before handoff.
//
// Usage:
//   GEO_AUDIT_ENGINE_DIR=/path/to/engine node verify.js domain1.com domain2.com[:slug] ...
//
// Reads the latest run per domain from $GEO_AUDIT_ENGINE_DIR/.data/runs/*/memory.json
// and reports the AIO trigger rate + errored-query count. A domain is OK when
// trigger > 0 and errored queries are few (<= threshold). A run that is still
// collecting or was stopped part-way is PART. Anything else is BAD and must be
// re-run solo before the report is used. Exit code is non-zero if any domain is
// BAD, PART or missing, so callers can gate on it.
const fs = require("fs");
const path = require("path");

const ERR_THRESHOLD = Number(process.env.GEO_AUDIT_ERR_THRESHOLD || 5);
const WINDOW_SEC = Number(process.env.GEO_AUDIT_VERIFY_WINDOW || 0); // 0 = no time filter

const domainOf = (a) => a.split(":")[0].toLowerCase();
const pad = (s, n) => String(s).padEnd(n);
const padStart = (s, n) => String(s).padStart(n);

function main() {
  const engine = process.env.GEO_AUDIT_ENGINE_DIR;
  if (!engine) {
    console.log("ERROR: set GEO_AUDIT_ENGINE_DIR");
    return 2;
  }
  const args = process.argv.slice(2).filter((a) => a.trim());
  if (!args.length) {
    console.log("usage: verify.js domain1.com domain2.com ...");
    return 2;
  }
  const wanted = new Set(args.map(domainOf));

  const runsDir = path.join(engine, ".data", "runs");
  const now = Date.now() / 1000;
  const best = {}; // domain -> {trigger, errors, total, mtime}

  let runs = [];
  try {
    runs = fs.readdirSync(runsDir);
  } catch {
    runs = [];
  }

  for (const dir of runs) {
    const mp = path.join(runsDir, dir, "memory.json");
    let st;
    try {
      st = fs.statSync(mp);
    } catch {
      continue;
    }
    const mt = st.mtimeMs / 1000;
    if (WINDOW_SEC && now - mt > WINDOW_SEC) continue;

    let m;
    try {
      m = JSON.parse(fs.readFileSync(mp, "utf8"));
    } catch {
      continue;
    }
    const d = ((m.meta || {}).domain || "").toLowerCase();
    const aio = m.aio || {};
    // A run still collecting (or stopped mid-way) saves partial results with
    // aio.partial, and before its first query only meta.phase "collecting".
    // Both count as the latest run, so a stopped re-run is never hidden behind
    // an older clean one.
    const partial = aio.partial === true || (m.meta || {}).phase === "collecting";
    if (!wanted.has(d) || (!Array.isArray(aio.results) && !partial)) continue;

    const results = Array.isArray(aio.results) ? aio.results : [];
    const errs = results.filter((r) => r && r.error).length;
    const trig = aio.aioTriggerRatePct || 0;
    if (!best[d] || mt > best[d].mtime) {
      best[d] = { trigger: trig, errors: errs, done: results.length, total: aio.queryCount || (m.meta || {}).queryCount || results.length, partial, mtime: mt };
    }
  }

  const bad = [];
  console.log(`${pad("status", 6)} ${pad("domain", 24)} ${padStart("trigger", 8)}  errors`);
  console.log("-".repeat(52));
  for (const a of args) {
    const d = domainOf(a);
    const b = best[d];
    if (!b) {
      console.log(`${pad("MISS", 6)} ${pad(d, 24)} ${padStart("--", 8)}  (no run found)`);
      bad.push(d);
      continue;
    }
    if (b.partial) {
      bad.push(d);
      console.log(`${pad("PART", 6)} ${pad(d, 24)} ${padStart("--", 8)}  (incomplete: ${b.done}/${b.total} queries read; still running or stopped)`);
      continue;
    }
    const ok = b.trigger > 0 && b.errors <= ERR_THRESHOLD;
    if (!ok) bad.push(d);
    console.log(`${pad(ok ? "OK" : "BAD", 6)} ${pad(d, 24)} ${padStart(b.trigger + "%", 8)}  ${b.errors}/${b.total}`);
  }

  console.log("-".repeat(52));
  if (bad.length) {
    console.log(`\n${bad.length} need re-run (solo): ${bad.join(", ")}`);
    return 1;
  }
  console.log(`\nAll ${args.length} clean.`);
  return 0;
}

if (require.main === module) process.exit(main());
