#!/usr/bin/env node
// Skill-side entry for the insight fact sheet (SKILL.md step 7). The logic lives
// in the engine (src/insights.js, scripts/insights.js); this only locates it.
//
// Usage:
//   GEO_AUDIT_ENGINE_DIR=/path/to/engine node insights.js [--json] domain1.com domain2.com[:slug] ...
const path = require("path");
const { spawnSync } = require("child_process");

const engine = process.env.GEO_AUDIT_ENGINE_DIR;
if (!engine) { console.log("ERROR: set GEO_AUDIT_ENGINE_DIR"); process.exit(2); }
const r = spawnSync(process.execPath, [path.join(engine, "scripts", "insights.js"), ...process.argv.slice(2)], { stdio: "inherit" });
process.exit(r.status == null ? 1 : r.status);
